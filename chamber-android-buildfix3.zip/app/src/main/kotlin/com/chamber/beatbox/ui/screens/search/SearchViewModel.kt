package com.chamber.beatbox.ui.screens.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chamber.beatbox.data.audio.MetronomeEngine
import com.chamber.beatbox.data.db.entities.EntryEntity
import com.chamber.beatbox.data.repository.EntryRepository
import com.chamber.beatbox.ui.navigation.Routes
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SearchCommand(
    val label: String,
    val meta: String,
    val glyph: String,
    val action: SearchAction
)

sealed class SearchAction {
    data class Navigate(val route: String) : SearchAction()
    data class SetBpm(val bpm: Int) : SearchAction()
    data class NewEntry(val kind: String, val name: String = "") : SearchAction()
    object StartMetronome : SearchAction()
    object ToggleMetronome : SearchAction()
}

data class SearchUiState(
    val query: String = "",
    val results: List<EntryEntity> = emptyList(),
    val commands: List<SearchCommand> = emptyList()
)

@OptIn(FlowPreview::class)
@HiltViewModel
class SearchViewModel @Inject constructor(
    private val repo: EntryRepository,
    private val metronome: MetronomeEngine
) : ViewModel() {

    private val _query = MutableStateFlow("")
    private val _results = MutableStateFlow<List<EntryEntity>>(emptyList())
    private val _commands = MutableStateFlow<List<SearchCommand>>(emptyList())

    val uiState: StateFlow<SearchUiState> = combine(_query, _results, _commands) { q, r, c ->
        SearchUiState(q, r, c)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SearchUiState())

    init {
        viewModelScope.launch {
            _query.debounce(180).distinctUntilChanged().collect { q ->
                _commands.value = parseCommands(q)
                _results.value = if (q.isBlank() || q.trimStart().startsWith("/")) emptyList()
                else repo.search(q.trim())
            }
        }
    }

    fun setQuery(q: String) { _query.value = q }
    fun clear() { _query.value = ""; _results.value = emptyList(); _commands.value = emptyList() }

    fun execute(cmd: SearchCommand, onNavigate: (String) -> Unit, onNewEntry: (String) -> Unit) {
        when (val a = cmd.action) {
            is SearchAction.Navigate -> onNavigate(a.route)
            is SearchAction.SetBpm -> {
                metronome.setBpm(a.bpm)
                if (!metronome.isRunning) metronome.start()
            }
            is SearchAction.NewEntry -> {
                viewModelScope.launch {
                    val e = repo.newEntry(a.kind, a.name.ifBlank { "New ${a.kind}" })
                    repo.upsert(e)
                    onNewEntry(e.id)
                }
            }
            SearchAction.StartMetronome -> { if (!metronome.isRunning) metronome.start() }
            SearchAction.ToggleMetronome -> metronome.toggle()
        }
        clear()
    }

    private fun parseCommands(raw: String): List<SearchCommand> {
        val s = raw.trim().lowercase()
        if (s.isEmpty()) return emptyList()
        val out = mutableListOf<SearchCommand>()

        // Plain number or "bpm 140"
        val numOnly = Regex("^(\\d{2,3})$").find(s)
        val bpmWord = Regex("bpm\\s+(\\d{2,3})").find(s)
        val bpmVal = (numOnly ?: bpmWord)?.groupValues?.getOrNull(1)?.toIntOrNull()
        if (bpmVal != null && bpmVal in 30..300) {
            out += SearchCommand("Set metronome to $bpmVal BPM", "TEMPO", "♩", SearchAction.SetBpm(bpmVal))
        }

        fun addNav(keys: List<String>, label: String, glyph: String, route: String) {
            if (keys.any { s.contains(it) }) {
                out += SearchCommand(label, "GO", glyph, SearchAction.Navigate(route))
            }
        }

        addNav(listOf("drill"), "Open Drill", "DRL", Routes.DRILL)
        addNav(listOf("battle"), "Start Battle mode", "⚔", Routes.BATTLE)
        addNav(listOf("trainer", "warm"), "Open Trainer", "⏱", Routes.TRAINER)
        addNav(listOf("viz", "visualizer"), "Open Visualizer", "◉", Routes.VIZ)
        addNav(listOf("quests"), "Show Quests", "★", Routes.QUESTS)
        addNav(listOf("stats"), "Show Stats", "∑", Routes.STATS)
        addNav(listOf("pattern", "lab"), "Pattern Lab", "▦", Routes.PATTERN)
        addNav(listOf("data", "backup", "export"), "Data / Backup", "▤", Routes.DATA)
        addNav(listOf("home"), "Dashboard", "⌂", Routes.HOME)
        addNav(listOf("godmode", "god", "map"), "Open GODMODE", "G", Routes.GODMODE)

        if (s.contains("metro") || s == "/m" || s == "click") {
            out += SearchCommand("Toggle metronome", "TEMPO", "♩", SearchAction.ToggleMetronome)
        }

        if (s.contains("new idea") || s.contains("/idea")) {
            out += SearchCommand("New idea", "CREATE", "+", SearchAction.NewEntry("idea"))
        }
        if (s.contains("new technique") || s.contains("/technique")) {
            out += SearchCommand("New technique", "CREATE", "+", SearchAction.NewEntry("technique"))
        }
        if (s.contains("new pattern")) {
            out += SearchCommand("New pattern", "CREATE", "+", SearchAction.NewEntry("pattern"))
        }
        if (s.contains("new champ") || s.contains("new routine")) {
            out += SearchCommand("New routine", "CREATE", "+", SearchAction.NewEntry("champ"))
        }
        if (s.contains("new oneshot") || s.contains("1 shot")) {
            out += SearchCommand("New 1-shot", "CREATE", "+", SearchAction.NewEntry("oneshot"))
        }
        if (s.startsWith("/new") || s == "new") {
            out += SearchCommand("New idea", "CREATE", "+", SearchAction.NewEntry("idea"))
            out += SearchCommand("New technique", "CREATE", "+", SearchAction.NewEntry("technique"))
        }

        return out.distinctBy { it.label }.take(8)
    }
}
