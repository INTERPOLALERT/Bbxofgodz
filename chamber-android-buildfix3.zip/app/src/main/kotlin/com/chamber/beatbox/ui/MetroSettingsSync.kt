
package com.chamber.beatbox.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chamber.beatbox.data.audio.MetronomeEngine
import com.chamber.beatbox.data.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MetroSettingsViewModel @Inject constructor(
    private val settings: SettingsRepository,
    private val metro: MetronomeEngine
) : ViewModel() {
    fun load() {
        viewModelScope.launch {
            metro.setBpm(settings.bpm.first())
            metro.setBeats(settings.beats.first())
        }
    }
    fun persistBpm(bpm: Int) {
        viewModelScope.launch { settings.setBpm(bpm) }
    }
}

@Composable
fun MetroSettingsSync(vm: MetroSettingsViewModel = hiltViewModel()) {
    LaunchedEffect(Unit) { vm.load() }
}
