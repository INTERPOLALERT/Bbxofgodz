package com.chamber.beatbox.ui.screens.godmode

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chamber.beatbox.data.db.entities.EntryEntity
import com.chamber.beatbox.data.drill.DrillBuilder
import com.chamber.beatbox.data.repository.EntryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import javax.inject.Inject
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

data class GraphNode(
    val id: String,
    val name: String,
    val kind: String,
    val cat: String?,
    val bpm: Int?,
    val pin: Boolean,
    var x: Float = 0f,
    var y: Float = 0f,
    var vx: Float = 0f,
    var vy: Float = 0f
)

data class GraphEdge(val from: String, val to: String)

data class CoachInsight(
    val glyph: String,
    val title: String,
    val body: String,
    val routeHint: String? = null
)

data class GodmodeUiState(
    val nodes: List<GraphNode> = emptyList(),
    val edges: List<GraphEdge> = emptyList(),
    val insights: List<CoachInsight> = emptyList(),
    val selectedId: String? = null,
    val nodeCount: Int = 0,
    val edgeCount: Int = 0,
    val orphanCount: Int = 0
)

@HiltViewModel
class GodmodeViewModel @Inject constructor(
    private val repo: EntryRepository
) : ViewModel() {

    private val _selected = MutableStateFlow<String?>(null)
    private val _tick = MutableStateFlow(0)

    val uiState: StateFlow<GodmodeUiState> = combine(
        repo.observeAll(),
        _selected,
        _tick
    ) { entries, selected, _ ->
        buildState(entries.filter { !it.deleted }, selected)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), GodmodeUiState())

    private var simNodes: MutableList<GraphNode> = mutableListOf()
    private var simEdges: List<GraphEdge> = emptyList()
    private var initialized = false

    fun select(id: String?) { _selected.value = id }

    /** One physics step — call from Compose animation loop. */
    fun stepPhysics(width: Float, height: Float) {
        if (simNodes.isEmpty() || width <= 0f || height <= 0f) return
        val nodes = simNodes
        val edges = simEdges
        val cx = width / 2f
        val cy = height / 2f

        // repulsive force (all pairs, O(n²) ok for small libraries)
        for (i in nodes.indices) {
            for (j in i + 1 until nodes.size) {
                val a = nodes[i]; val b = nodes[j]
                var dx = a.x - b.x
                var dy = a.y - b.y
                var dist = sqrt(dx * dx + dy * dy).coerceAtLeast(8f)
                val force = 2800f / (dist * dist)
                dx = dx / dist * force
                dy = dy / dist * force
                a.vx += dx; a.vy += dy
                b.vx -= dx; b.vy -= dy
            }
        }

        // attractive spring along edges
        val byId = nodes.associateBy { it.id }
        for (e in edges) {
            val a = byId[e.from] ?: continue
            val b = byId[e.to] ?: continue
            var dx = b.x - a.x
            var dy = b.y - a.y
            val dist = sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
            val force = (dist - 90f) * 0.02f
            dx = dx / dist * force
            dy = dy / dist * force
            a.vx += dx; a.vy += dy
            b.vx -= dx; b.vy -= dy
        }

        // mild center gravity + damping + bounds
        for (n in nodes) {
            n.vx += (cx - n.x) * 0.002f
            n.vy += (cy - n.y) * 0.002f
            n.vx *= 0.82f
            n.vy *= 0.82f
            n.x = (n.x + n.vx).coerceIn(24f, width - 24f)
            n.y = (n.y + n.vy).coerceIn(24f, height - 24f)
        }
        _tick.value = _tick.value + 1
    }

    fun reseedLayout(width: Float, height: Float) {
        val rnd = Random(System.currentTimeMillis())
        simNodes.forEach {
            it.x = 40f + rnd.nextFloat() * (width - 80f).coerceAtLeast(40f)
            it.y = 40f + rnd.nextFloat() * (height - 80f).coerceAtLeast(40f)
            it.vx = 0f; it.vy = 0f
        }
        _tick.value++
    }

    private fun buildState(entries: List<EntryEntity>, selected: String?): GodmodeUiState {
        val idSet = entries.map { it.id }.toSet()
        val edges = mutableListOf<GraphEdge>()
        for (e in entries) {
            for (link in parseLinks(e.links)) {
                if (link in idSet && link != e.id) {
                    // undirected uniqueness
                    val a = minOf(e.id, link)
                    val b = maxOf(e.id, link)
                    if (edges.none { it.from == a && it.to == b }) {
                        edges += GraphEdge(a, b)
                    }
                }
            }
        }

        // Keep simulation node positions across rebuilds
        val oldPos = simNodes.associate { it.id to (it.x to it.y) }
        val nodes = entries.map { e ->
            val (ox, oy) = oldPos[e.id] ?: (0f to 0f)
            GraphNode(
                id = e.id,
                name = e.name.ifBlank { "Untitled" },
                kind = e.kind,
                cat = e.cat,
                bpm = e.bpm,
                pin = e.pin,
                x = ox,
                y = oy
            )
        }.toMutableList()

        if (!initialized && nodes.isNotEmpty()) {
            val rnd = Random(42)
            nodes.forEachIndexed { i, n ->
                val angle = i * 2.4f
                val r = 40f + i * 3f
                n.x = 200f + cos(angle) * r
                n.y = 200f + sin(angle) * r
            }
            initialized = true
        }
        // If new nodes appeared at 0,0 scatter them
        nodes.filter { it.x == 0f && it.y == 0f }.forEachIndexed { i, n ->
            n.x = 120f + i * 18f
            n.y = 120f + (i % 7) * 22f
        }

        simNodes = nodes
        simEdges = edges

        val linkedIds = edges.flatMap { listOf(it.from, it.to) }.toSet()
        val orphans = nodes.filter { it.id !in linkedIds && it.kind != "genre" }

        return GodmodeUiState(
            nodes = nodes.toList(),
            edges = edges,
            insights = buildInsights(entries, edges, orphans),
            selectedId = selected,
            nodeCount = nodes.size,
            edgeCount = edges.size,
            orphanCount = orphans.size
        )
    }

    private fun buildInsights(
        entries: List<EntryEntity>,
        edges: List<GraphEdge>,
        orphans: List<GraphNode>
    ): List<CoachInsight> {
        val list = mutableListOf<CoachInsight>()
        val byKind = entries.groupBy { it.kind }

        if (entries.isEmpty()) {
            list += CoachInsight("·", "Empty map", "Create entries and link them — the graph fills itself.")
            return list
        }

        list += CoachInsight(
            "∑",
            "${entries.size} nodes · ${edges.size} links",
            if (edges.isEmpty()) "Nothing is linked yet. Cross-reference techniques, genres, and routines."
            else "Density ${(edges.size * 100 / entries.size.coerceAtLeast(1))}%. Tap a node to open it."
        )

        if (orphans.isNotEmpty()) {
            val sample = orphans.take(3).joinToString { it.name }
            list += CoachInsight(
                "○",
                "${orphans.size} unlinked entries",
                "Islands: $sample${if (orphans.size > 3) "…" else ""}. Link them so the coach can route practice."
            )
        }

        val champs = byKind["champ"].orEmpty().filter { it.status != "Completed" }
        if (champs.isNotEmpty()) {
            val oldest = champs.minByOrNull { it.updatedAt }
            list += CoachInsight(
                "+",
                "${champs.size} open routines",
                oldest?.let { "Oldest: ${it.name}. Full pass, no stopping to fix things." }
                    ?: "Championship material waiting."
            )
        }

        val gaps = DrillBuilder.bpmGaps(entries)
        if (gaps.isNotEmpty()) {
            list += CoachInsight(
                "♩",
                "Tempo gaps",
                gaps.take(3).joinToString { it.label } + " — judges hear missing range first."
            )
        }

        val coldGenres = byKind["genre"].orEmpty().filter { g ->
            parseLinks(g.links).isEmpty()
        }
        if (coldGenres.isNotEmpty()) {
            list += CoachInsight(
                "♫",
                "${coldGenres.size} cold genres",
                coldGenres.take(3).joinToString { it.name } + " never connected to work."
            )
        }

        val techs = byKind["technique"].orEmpty()
        val weak = techs.filter { t ->
            val logs = t.log
            !logs.contains("confidence") || logs.contains("\"v\":\"1\"") || logs.contains("\"v\":\"2\"")
        }
        if (weak.isNotEmpty()) {
            list += CoachInsight(
                "TEC",
                "${weak.size} techniques need reps",
                weak.take(3).joinToString { it.name } + " — low or missing confidence."
            )
        }

        if (byKind["pattern"].isNullOrEmpty()) {
            list += CoachInsight("▦", "No patterns yet", "A groove you can only feel is one you cannot repeat on demand.")
        }

        val pins = entries.filter { it.pin }
        if (pins.isNotEmpty()) {
            list += CoachInsight("📌", "${pins.size} pinned", pins.take(4).joinToString { it.name })
        }

        return list.take(8)
    }

    private fun parseLinks(json: String): List<String> {
        if (json.isBlank() || json == "[]") return emptyList()
        return runCatching {
            Json.parseToJsonElement(json).jsonArray.mapNotNull { it.jsonPrimitive.content }
        }.getOrElse {
            Regex("\"([^\"]+)\"").findAll(json).map { it.groupValues[1] }.toList()
        }
    }
}
