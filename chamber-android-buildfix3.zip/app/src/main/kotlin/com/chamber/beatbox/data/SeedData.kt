package com.chamber.beatbox.data

import com.chamber.beatbox.data.repository.EntryRepository
import com.chamber.beatbox.data.repository.SettingsRepository
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Matches HTML GENRES seed list — populated once on first launch.
 */
@Singleton
class SeedData @Inject constructor(
    private val repo: EntryRepository,
    private val settings: SettingsRepository
) {
    companion object {
        val GENRES = listOf(
            "Hip-Hop","House","Techno","Drum & Bass","Liquid D&B","Neurofunk","Jungle","Garage","UK Garage",
            "Grime","Dubstep","Trap","Pop","R&B","Reggae","Dancehall","Trance","Breakbeat","Funk","Soul","Jazz","Rock",
            "Metal","Drumstep","Dub","Afrobeat","Amapiano","Latin","Reggaeton","Experimental","Ambient"
        )
    }

    suspend fun ensureGenresSeeded() {
        if (settings.genresSeeded.first()) return
        val existing = repo.observeAll().first().filter { it.kind == "genre" }.map { it.name }.toSet()
        val toAdd = GENRES.filter { it !in existing }.map { name ->
            repo.newEntry("genre", name)
        }
        if (toAdd.isNotEmpty()) repo.upsertAll(toAdd)
        settings.setGenresSeeded(true)
    }
}
