package com.chamber.beatbox.data.audio

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Wraps MediaRecorder for AAC/M4A recording.
 *
 * Files are written to the app's private files directory under recordings/.
 * They are referenced in the database by absolute path and shared externally
 * via FileProvider when needed (export, share sheet).
 *
 * Lifecycle:
 *   prepare() → start() → pause()/resume() → stop() → [returns File]
 *
 * The caller (ViewModel) is responsible for requesting RECORD_AUDIO at
 * runtime before calling start(). RecorderEngine assumes permission is granted.
 */
@Singleton
class RecorderEngine @Inject constructor(
    @ApplicationContext private val context: Context
) {
    sealed class State {
        object Idle      : State()
        object Preparing : State()
        object Recording : State()
        object Paused    : State()
        data class Error(val message: String) : State()
    }

    private val _state = MutableStateFlow<State>(State.Idle)
    val state: StateFlow<State> = _state.asStateFlow()

    private var recorder: MediaRecorder? = null
    private var currentFile: File? = null

    /** Milliseconds elapsed, updated every second by the caller's timer. */
    var elapsedMs: Long = 0L
        private set
    private var startMs: Long = 0L
    private var pausedMs: Long = 0L

    val isRecording: Boolean get() = _state.value is State.Recording
    val isPaused: Boolean    get() = _state.value is State.Paused

    val recordingDir: File get() =
        File(context.filesDir, "recordings").also { it.mkdirs() }

    /**
     * Starts a new recording. Returns the file that will be written.
     * Throws if called while already recording.
     */
    fun start(): File {
        check(_state.value is State.Idle) { "Already recording" }
        _state.value = State.Preparing

        val file = File(recordingDir, generateFilename())
        currentFile = file
        startMs = System.currentTimeMillis()
        pausedMs = 0L

        val rec = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }

        try {
            rec.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128_000)
                setAudioSamplingRate(44100)
                setOutputFile(file.absolutePath)
                setOnErrorListener { _, what, extra ->
                    _state.value = State.Error("MediaRecorder error: what=$what extra=$extra")
                    cleanup()
                }
                prepare()
                start()
            }
            recorder = rec
            _state.value = State.Recording
        } catch (e: Exception) {
            rec.release()
            file.delete()
            currentFile = null
            _state.value = State.Error(e.message ?: "Unknown error")
            throw e
        }
        return file
    }

    fun pause() {
        val rec = recorder ?: return
        if (_state.value !is State.Recording) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            rec.pause()
            pausedMs += System.currentTimeMillis() - startMs
            _state.value = State.Paused
        }
        // Below API 24, pause is not supported — noop (caller should handle)
    }

    fun resume() {
        val rec = recorder ?: return
        if (_state.value !is State.Paused) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            rec.resume()
            startMs = System.currentTimeMillis()
            _state.value = State.Recording
        }
    }

    /**
     * Stops recording and returns the completed file.
     * Returns null if nothing was being recorded.
     */
    fun stop(): File? {
        val rec = recorder ?: return null
        val file = currentFile ?: return null
        return try {
            rec.stop()
            file
        } catch (e: Exception) {
            file.delete()
            null
        } finally {
            cleanup()
        }
    }

    /** Discard the current recording without saving. */
    fun cancel() {
        try { recorder?.stop() } catch (_: Exception) {}
        currentFile?.delete()
        cleanup()
    }

    fun updateElapsed() {
        elapsedMs = when (_state.value) {
            is State.Recording -> pausedMs + (System.currentTimeMillis() - startMs)
            is State.Paused    -> pausedMs
            else               -> 0L
        }
    }

    private fun cleanup() {
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        currentFile = null
        startMs = 0L
        pausedMs = 0L
        elapsedMs = 0L
        _state.value = State.Idle
    }

    private fun generateFilename(): String {
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return "REC_$ts.m4a"
    }
}
