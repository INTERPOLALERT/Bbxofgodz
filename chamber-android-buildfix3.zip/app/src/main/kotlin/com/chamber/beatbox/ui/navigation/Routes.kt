package com.chamber.beatbox.ui.navigation

/**
 * Typed navigation routes.
 *
 * The HTML uses hash routing: #/s/{sectionId} and #/e/{entryId}.
 * We mirror that structure with Navigation Compose.
 *
 * All sections from the HTML's SECTIONS array are represented here.
 * The `id` strings match the HTML's section IDs exactly so that
 * future data import/export doesn't need a mapping table.
 */
object Routes {

    // ── Section routes (type = "section") ─────────────────────────────────────
    const val HOME       = "s/home"
    const val CHAMP      = "s/champ"
    const val IDEAS      = "s/ideas"
    const val BARS4      = "s/bars4"
    const val BARS8      = "s/bars8"
    const val BARS16     = "s/bars16"
    const val BARS32     = "s/bars32"
    const val BARS64     = "s/bars64"
    const val ONESHOT    = "s/oneshot"
    const val PATTERN    = "s/pattern"
    const val SETLIST    = "s/setlist"
    const val MUSICALITY = "s/musicality"
    const val TECHNIQUE  = "s/technique"
    const val TONGUEBASS = "s/tonguebass"
    const val SFX        = "s/sfx"
    const val SINGING    = "s/singing"
    const val QUESTS     = "s/quests"
    const val TRAINER    = "s/trainer"
    const val DRILL      = "s/drill"
    const val VIZ        = "s/viz"
    const val BATTLE     = "s/battle"
    const val SOCIAL     = "s/social"
    const val VOCODE     = "s/vocode"
    const val GENRES     = "s/genres"
    const val PRACTICE   = "s/practice"
    const val GOALS      = "s/goals"
    const val STATS      = "s/stats"
    const val GODMODE    = "s/godmode"
    const val DATA       = "s/data"
    const val SEARCH     = "s/search"

    // ── Entry route (type = "entry") ──────────────────────────────────────────
    // Argument: entryId (String)
    const val ENTRY_ARG  = "entryId"
    const val ENTRY      = "e/{$ENTRY_ARG}"

    fun entry(id: String) = "e/$id"

    // ── All section descriptors (drives the chip strip and full menu) ─────────
    // Mirrors the HTML SECTIONS array in the same order. `page` = custom renderer;
    // `kind` = list-based section backed by the entries table.
    data class SectionInfo(
        val id:    String,
        val glyph: String,
        val title: String,
        val desc:  String,
        val group: String,
        val kind:  String?   = null,  // entry kind if list-backed
        val cat:   String?   = null,  // technique cat filter
        val bars:  Int?      = null,  // bars count filter
        val page:  String?   = null,  // custom page renderer id
        val route: String
    )

    val sections: List<SectionInfo> = listOf(
        SectionInfo("home",      "⌂",   "Home",         "DASHBOARD",                          "MAIN",   page="home",      route=HOME),
        SectionInfo("champ",     "+",   "Championship", "ROUTINE TRACKER",                    "MAIN",   kind="champ",     route=CHAMP),
        SectionInfo("ideas",     "!",   "Ideas",        "CAPTURE ANYTHING",                   "MAIN",   kind="idea",      route=IDEAS),
        SectionInfo("bars4",     "4",   "4 Bars",       "SHORT EXERCISES",                    "BARS",   kind="bars", bars=4,   route=BARS4),
        SectionInfo("bars8",     "8",   "8 Bars",       "FULL BEAT",                          "BARS",   kind="bars", bars=8,   route=BARS8),
        SectionInfo("bars16",    "16",  "16 Bars",      "FULL ARRANGEMENT",                   "BARS",   kind="bars", bars=16,  route=BARS16),
        SectionInfo("bars32",    "32",  "32 Bars",      "EXTENDED FORM",                      "BARS",   kind="bars", bars=32,  route=BARS32),
        SectionInfo("bars64",    "64",  "64 Bars",      "LONG FORM",                          "BARS",   kind="bars", bars=64,  route=BARS64),
        SectionInfo("oneshot",   "1",   "1-Shots",      "SINGLE SOUNDS",                      "BARS",   kind="oneshot",   route=ONESHOT),
        SectionInfo("pattern",   "▦",   "Pattern Lab",  "STEP SEQUENCER",                     "BARS",   kind="pattern",   route=PATTERN),
        SectionInfo("setlist",   "≡",   "Setlists",     "SETLIST BUILDER",                    "BARS",   kind="setlist",   route=SETLIST),
        SectionInfo("musicality","MUS", "Musicality",   "TECHNIQUE LIBRARY",                  "SKILLS", kind="technique", cat="musicality", route=MUSICALITY),
        SectionInfo("technique", "TEC", "Technique",    "TECHNIQUE LIBRARY",                  "SKILLS", kind="technique", cat="technique",  route=TECHNIQUE),
        SectionInfo("tonguebass","TB",  "Tongue Bass",  "TECHNIQUE LIBRARY",                  "SKILLS", kind="technique", cat="tonguebass", route=TONGUEBASS),
        SectionInfo("sfx",       "SFX", "SFX",          "TECHNIQUE LIBRARY",                  "SKILLS", kind="technique", cat="sfx",        route=SFX),
        SectionInfo("singing",   "SNG", "Singing",      "TECHNIQUE LIBRARY",                  "SKILLS", kind="technique", cat="singing",     route=SINGING),
        SectionInfo("quests",    "★",   "Quests",       "DAILY CHALLENGES · XP · BADGES",     "TRAIN",  page="quests",    route=QUESTS),
        SectionInfo("trainer",   "⏱",   "Trainer",      "SPEED · GAP · SESSION TIMER · WARM-UP","TRAIN",page="trainer",   route=TRAINER),
        SectionInfo("drill",     "DRL", "Drill",        "AUTO-BUILT SESSION FROM YOUR DATA",  "TRAIN",  page="drill",     route=DRILL),
        SectionInfo("viz",       "◉",   "Visualizer",   "LIVE MIC · SPECTRUM · PARTICLES",   "TRAIN",  page="viz",       route=VIZ),
        SectionInfo("battle",    "⚔",   "Battle Mode",  "ROUND TIMER · OPPONENT GENERATOR",  "TRAIN",  page="battle",    route=BATTLE),
        SectionInfo("social",    "SOC", "Social Media", "CONTENT PIPELINE",                   "OUTPUT", kind="social",    route=SOCIAL),
        SectionInfo("vocode",    "VOC", "Vocode",       "VOCODERS · VOICE FX · FORMANT",      "OUTPUT", kind="vocode",    route=VOCODE),
        SectionInfo("genres",    "GEN", "Genres",       "GENRE LIBRARY — EXPANDABLE",         "LIBRARY",kind="genre",     route=GENRES),
        SectionInfo("practice",  "PRC", "Practice",     "SESSIONS & ROUTINES",                "SYSTEM", kind="session",   route=PRACTICE),
        SectionInfo("goals",     "GOA", "Goals",        "TARGETS & DEADLINES",                "SYSTEM", kind="goal",      route=GOALS),
        SectionInfo("stats",     "∑",   "Stats",        "STREAKS · TIME · BALANCE · BADGES",  "SYSTEM", page="stats",     route=STATS),
        SectionInfo("godmode",   "G",   "GODMODE",      "MAP OF EVERYTHING + COACH",          "SYSTEM", page="godmode",   route=GODMODE),
        SectionInfo("data",      "▤",   "Data / Backup","EXPORT · IMPORT · STORAGE",          "SYSTEM", page="data",      route=DATA)
    )

    val sectionById: Map<String, SectionInfo> = sections.associateBy { it.id }

    /** Sections shown in the horizontal chip strip (same as HTML — all of them). */
    val chipSections: List<SectionInfo> = sections

    /** Groups for the full menu sheet. */
    val groups: List<String> = sections.map { it.group }.distinct()
}
