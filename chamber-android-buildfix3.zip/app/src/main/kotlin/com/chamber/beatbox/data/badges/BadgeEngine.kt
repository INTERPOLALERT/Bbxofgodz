package com.chamber.beatbox.data.badges

import com.chamber.beatbox.data.db.entities.EntryEntity
import com.chamber.beatbox.data.db.entities.FileMetaEntity
import com.chamber.beatbox.data.db.entities.PracticeLogEntity

/**
 * Achievement / badge system ported from the HTML CHAMBER badge list.
 * Each badge is evaluated against live Room data. Unlocked badges are
 * stored as a JSON string array on GameStateEntity.badgesJson.
 */
object BadgeEngine {

    data class Badge(
        val id: String,
        val name: String,
        val icon: String,
        val description: String,
        val check: (BadgeContext) -> Boolean
    )

    data class BadgeContext(
        val entries: List<EntryEntity>,
        val sessions: List<PracticeLogEntity>,
        val fileCount: Int,
        val streak: Int,
        val totalMinutes: Int,
        val topBpm: Int,
        val kindCounts: Map<String, Int>,
        val hasRecording: Boolean,
        val hasPattern: Boolean,
        val hasChamp: Boolean,
        val genreCount: Int
    )

    val ALL: List<Badge> = listOf(
        Badge("first_blood", "First Blood", "●", "Log your first practice session") { it.sessions.isNotEmpty() },
        Badge("on_tape", "On Tape", "◉", "Attach or record your first audio file") { it.hasRecording },
        Badge("archivist", "Archivist", "▤", "Create 25 entries of any kind") { it.entries.size >= 25 },
        Badge("librarian", "Librarian", "▦", "Create 100 entries") { it.entries.size >= 100 },
        Badge("sixteen", "Sixteen", "16", "Create a 16-bar exercise") {
            it.entries.any { e -> e.kind == "bars" && (e.bars == 16 || e.name.contains("16")) }
        },
        Badge("polyglot", "Polyglot", "♪", "Have entries in 5+ different genres") { it.genreCount >= 5 },
        Badge("speed_demon", "Speed Demon", "⚡", "Log a session or PR at 180+ BPM") { it.topBpm >= 180 },
        Badge("clockwork", "Clockwork", "⏱", "Maintain a 7-day practice streak") { it.streak >= 7 },
        Badge("iron_lungs", "Iron Lungs", "🔥", "Log 10+ hours of total practice") { it.totalMinutes >= 600 },
        Badge("marathoner", "Marathoner", "🏃", "Log 50+ hours of total practice") { it.totalMinutes >= 3000 },
        Badge("pattern_maker", "Pattern Maker", "▦", "Create your first pattern in Pattern Lab") { it.hasPattern },
        Badge("challenger", "Challenger", "⚔", "Create a championship routine entry") { it.hasChamp },
        Badge("technician", "Technician", "TEC", "Track 10+ techniques") { (it.kindCounts["technique"] ?: 0) >= 10 },
        Badge("ideas_man", "Ideas Man", "!", "Capture 20+ ideas") { (it.kindCounts["idea"] ?: 0) >= 20 },
        Badge("oneshot_king", "One-Shot King", "1", "Create 15+ one-shots") { (it.kindCounts["oneshot"] ?: 0) >= 15 },
        Badge("consistent", "Consistent", "★", "Practice on 30 different days") { it.sessions.map { s -> s.day }.toSet().size >= 30 },
        Badge("night_owl", "Night Owl", "☾", "Log a session after 10pm") {
            it.sessions.any { s ->
                val hour = java.time.Instant.ofEpochMilli(s.timestamp)
                    .atZone(java.time.ZoneId.systemDefault()).hour
                hour >= 22
            }
        },
        Badge("early_bird", "Early Bird", "☀", "Log a session before 7am") {
            it.sessions.any { s ->
                val hour = java.time.Instant.ofEpochMilli(s.timestamp)
                    .atZone(java.time.ZoneId.systemDefault()).hour
                hour < 7
            }
        },
        Badge("battle_tested", "Battle Tested", "⚔", "Complete 5 battle sessions") {
            it.sessions.count { s -> s.type == "battle" } >= 5
        },
        Badge("driller", "Driller", "DRL", "Complete 5 drill sessions") {
            it.sessions.count { s -> s.type == "drill" } >= 5
        },
        Badge("warm_blooded", "Warm-Blooded", "🔴", "Log 10 warm-up completions") {
            it.sessions.count { s -> s.focus.contains("warm", ignoreCase = true) } >= 10
        },
        Badge("first_blood_rec", "First Recording", "●", "Make your first microphone recording") { it.hasRecording }
    )

    /** Returns the list of badge IDs that should now be unlocked. */
    fun evaluate(ctx: BadgeContext, alreadyUnlocked: Set<String>): List<String> {
        return ALL.filter { it.id !in alreadyUnlocked && it.check(ctx) }.map { it.id }
    }

    fun badgeById(id: String): Badge? = ALL.find { it.id == id }
}
