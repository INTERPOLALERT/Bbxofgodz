package com.chamber.beatbox.ui.screens.quests

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.chamber.beatbox.ui.components.*
import com.chamber.beatbox.ui.theme.*
import com.chamber.beatbox.data.badges.BadgeEngine

@Composable
fun QuestsScreen(nav: NavHostController, vm: QuestsViewModel = hiltViewModel()) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.autoVerify() }
    val c = LocalChamberColors.current

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(ChamberDimens.ContentPaddingH)) {
        // Header with level + rank
        item {
            Spacer(Modifier.height(ChamberDimens.ContentPaddingV))
            SectionHead("★","Quests","DAILY CHALLENGES · XP · BADGES",Modifier.padding(bottom=14.dp))
        }

        // XP card
        item {
            Column(Modifier.fillMaxWidth().border(ChamberDimens.BorderThick, c.ink).padding(14.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("LEVEL ${state.level}", style = ChamberType.Brand, color = c.ink)
                        Text(state.rank, style = ChamberType.MonoLabel, color = c.muted)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("${state.xp} XP", style = ChamberType.TileBig, color = c.ink)
                        Text("${state.xpToNext} TO NEXT LEVEL", style = ChamberType.MonoTiny, color = c.muted)
                    }
                }
                Spacer(Modifier.height(10.dp))
                ChamberProgressBar(
                    label  = "XP PROGRESS",
                    value  = state.xpProgress * 100,
                    max    = 100,
                    suffix = "%"
                )
            }
            Spacer(Modifier.height(12.dp))
        }

        // Daily quests
        item { SectionLine("Daily Quests · Week ${state.weekKey}") }
        items(state.daily) { (def, qs) ->
            QuestCard(
                icon   = def.icon,
                title  = qs.title ?: def.title,
                xp     = def.xp,
                done   = qs.done,
                isBoss = false,
                onCheck = { vm.checkQuest(def.id) },
                onStart = { nav.navigate(questStartRoute(def.id)) }
            )
        }

        // Boss quest
        state.boss?.let { (def, qs) ->
            item {
                SectionLine("Boss Quest")
                QuestCard(
                    icon   = def.icon,
                    title  = qs.title ?: def.title,
                    xp     = def.xp,
                    done   = qs.done,
                    isBoss = true,
                    onCheck = { vm.checkQuest(def.id) },
                    onStart = { nav.navigate(questStartRoute(def.id)) }
                )
            }
        }


        // Badges
        item {
            SectionLine("Badges", count = state.badges.size)
            Spacer(Modifier.height(8.dp))
            if (state.badges.isEmpty()) {
                HintBox("Badges unlock automatically as you practice, record, create entries, and complete drills.")
            } else {
                state.badges.forEach { id ->
                    val b = BadgeEngine.badgeById(id)
                    Row(
                        Modifier.fillMaxWidth().border(ChamberDimens.BorderWidth, c.ink).padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(b?.icon ?: "★", style = ChamberType.Title, color = c.ink, modifier = Modifier.width(40.dp))
                        Column(Modifier.weight(1f)) {
                            Text(b?.name ?: id, style = ChamberType.BodyBold, color = c.ink)
                            Text(b?.description ?: "", style = ChamberType.Mono, color = c.muted)
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        // Rank ladder
        item {
            SectionLine("Rank Ladder")
            Spacer(Modifier.height(8.dp))
            val ranks = listOf("NOVICE","ROOKIE","APPRENTICE","JOURNEYMAN","SKILLED","ADEPT",
                "PROFICIENT","EXPERT","MASTER","GRANDMASTER","CHAMPION","ELITE","LEGEND","MYTHIC","TRANSCENDENT")
            ranks.forEachIndexed { i, rank ->
                val lvl = i + 1; val isReached = state.level >= lvl; val isCurrent = state.rank == rank
                Row(Modifier.fillMaxWidth().border(ChamberDimens.BorderWidth,
                    if (isCurrent) c.ink else c.muted).background(if (isCurrent) c.ink else c.bg).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("$lvl", style=ChamberType.Mono, color=if(isCurrent)c.bg else if(isReached)c.ink else c.muted, modifier=Modifier.width(36.dp))
                    Text(rank, style=if(isCurrent)ChamberType.BodyBold else ChamberType.Body,
                        color=if(isCurrent)c.bg else if(isReached)c.ink else c.muted, modifier=Modifier.weight(1f))
                    if (isCurrent) Text("YOU ARE HERE", style=ChamberType.MonoTiny, color=c.bg)
                    else if (!isReached) Text("LVL $lvl — ${QuestsViewModel.xpForLevel(lvl)} XP", style=ChamberType.MonoTiny, color=c.muted)
                }
            }
        }

        item { Spacer(Modifier.height(ChamberDimens.BottomPadding)) }
    }
}

@Composable
private fun QuestCard(
    icon: String,
    title: String,
    xp: Int,
    done: Boolean,
    isBoss: Boolean,
    onCheck: () -> Unit,
    onStart: (() -> Unit)? = null
) {
    // Matches HTML questCard: qtxt + qmeta + START → / MARK DONE
    val c = LocalChamberColors.current
    Column(
        Modifier.fillMaxWidth()
            .border(if (isBoss) 4.dp else ChamberDimens.BorderWidth, if (done) c.muted else c.ink)
            .background(if (done) c.ink else c.bg)
            .padding(12.dp)
    ) {
        Text(
            (if (done) "✓ " else "") + title,
            style = ChamberType.BodyBold,
            color = if (done) c.bg else c.ink
        )
        Spacer(Modifier.height(4.dp))
        Text(
            (if (isBoss) "BOSS · " else "") + "$xp XP · MANUAL",
            style = ChamberType.MonoLabel,
            color = if (done) c.bg.copy(alpha = 0.75f) else c.muted
        )
        if (!done) {
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (onStart != null) {
                    ChamberButton("START →", onClick = onStart, size = ButtonSize.Small)
                }
                ChamberButton("MARK DONE", onClick = onCheck, size = ButtonSize.Small)
            }
        }
    }
    Spacer(Modifier.height(4.dp))
}


private fun questStartRoute(defId: String): String = when {
    defId.contains("bars") || defId == "dyn1" || defId == "t6" || defId == "t17" -> Routes.BARS8
    defId.contains("oneshot") || defId == "dyn2" -> Routes.ONESHOT
    defId.contains("idea") || defId == "t5" || defId == "t16" -> Routes.IDEAS
    defId.contains("technique") || defId == "t7" || defId == "dyn5" || defId == "dyn7" -> Routes.TECHNIQUE
    defId.contains("battle") || defId == "t13" -> Routes.BATTLE
    defId.contains("warm") || defId == "t14" -> Routes.TRAINER
    defId.contains("drill") || defId.startsWith("dyn") -> Routes.DRILL
    defId.startsWith("b") -> Routes.STATS
    else -> Routes.TRAINER
}
