package com.chamber.beatbox.ui.components

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chamber.beatbox.data.audio.SequencerEngine
import com.chamber.beatbox.data.repository.EntryRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*

private val json = Json { ignoreUnknownKeys = true; isLenient = true }

@OptIn(FlowPreview::class)
@HiltViewModel(assistedFactory = PatternEditorViewModel.Factory::class)
class PatternEditorViewModel @AssistedInject constructor(
    private val sequencer: SequencerEngine,
    private val repo: EntryRepository,
    @Assisted val entryId: String
) : ViewModel() {

    @AssistedFactory
    interface Factory { fun create(entryId: String): PatternEditorViewModel }

    // Expose sequencer state as flows
    val currentStep: StateFlow<Int>  = sequencer.currentStep
    val isPlaying:   StateFlow<Boolean> = sequencer.isPlaying

    private val _grid = MutableStateFlow<Map<String, BooleanArray>>(
        SequencerEngine.LANES.associateWith { BooleanArray(16) }
    )
    val grid: StateFlow<Map<String, BooleanArray>> = _grid.asStateFlow()

    private val _mutedLanes = MutableStateFlow<Set<String>>(emptySet())
    val mutedLanes: StateFlow<Set<String>> = _mutedLanes.asStateFlow()

    private val _bpm = MutableStateFlow(120)
    val bpm: StateFlow<Int> = _bpm.asStateFlow()

    private val _stepCount = MutableStateFlow(16)
    val stepCount: StateFlow<Int> = _stepCount.asStateFlow()

    private val _swing = MutableStateFlow(0f)
    val swing: StateFlow<Float> = _swing.asStateFlow()

    init {
        // Load grid from entry's extraJson
        viewModelScope.launch {
            repo.observeById(entryId).filterNotNull().first().let { entry ->
                entry.bpm?.let { _bpm.value = it; sequencer.bpm = it }
                val extra = parseExtra(entry.extraJson)
                val gridJson = extra["grid"] ?: "{}"
                sequencer.loadGridFromJson(gridJson)
                _grid.value = sequencer.grid
                _stepCount.value = sequencer.grid.values.firstOrNull()?.size ?: 16
                val sw = extra["swing"]?.toFloatOrNull() ?: 0f
                _swing.value = sw; sequencer.swing = sw
            }
        }

        // Debounce-save grid changes back to the entry
        viewModelScope.launch {
            _grid.debounce(300).collect { newGrid ->
                sequencer.grid = newGrid
                val entry = repo.getById(entryId) ?: return@collect
                val extra = parseExtra(entry.extraJson).toMutableMap()
                extra["grid"] = sequencer.gridToJson()
                extra["swing"] = _swing.value.toString()
                repo.upsert(entry.copy(extraJson = json.encodeToString(extra),
                    bpm = _bpm.value, updatedAt = System.currentTimeMillis()))
            }
        }
    }

    fun togglePlay() {
        sequencer.bpm   = _bpm.value
        sequencer.swing = _swing.value
        sequencer.toggle()
    }

    fun toggleCell(lane: String, step: Int) {
        _grid.value = sequencer.toggleCell(lane, step)
    }

    fun toggleMute(lane: String) {
        val newMuted = _mutedLanes.value.toMutableSet()
        if (lane in newMuted) { newMuted.remove(lane); sequencer.mutedLanes.remove(lane) }
        else { newMuted.add(lane); sequencer.mutedLanes.add(lane) }
        _mutedLanes.value = newMuted
    }

    fun clearAll() {
        sequencer.clearAll(); _grid.value = sequencer.grid
    }

    fun setBpm(v: Int) {
        val clamped = v.coerceIn(30, 300)
        _bpm.value = clamped; sequencer.bpm = clamped
    }

    fun setStepCount(n: Int) {
        sequencer.setStepCount(n)
        _grid.value = sequencer.grid
        _stepCount.value = n
    }

    fun setSwing(v: Float) {
        _swing.value = v; sequencer.swing = v
    }

    override fun onCleared() { sequencer.stop() }

    private fun parseExtra(extraJson: String): Map<String, String> = runCatching {
        json.parseToJsonElement(extraJson).jsonObject
            .mapValues { it.value.let { v -> if (v is JsonPrimitive) v.content else v.toString() } }
    }.getOrElse { emptyMap() }
}
