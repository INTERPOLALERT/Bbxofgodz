package com.chamber.beatbox.ui.screens.trainer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chamber.beatbox.data.audio.MetronomeEngine
import com.chamber.beatbox.data.db.entities.PracticeLogEntity
import com.chamber.beatbox.data.repository.EntryRepository
import com.chamber.beatbox.data.repository.SettingsRepository
import com.chamber.beatbox.data.drill.DrillBuilder
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.time.LocalDate
import javax.inject.Inject

data class TrainerUiState(
    val bpm: Int = 100,
    // Speed ramp
    val rampRunning: Boolean = false,
    val rampEveryBars: Int = 4,
    val rampStepBpm: Int = 2,
    val rampMaxBpm: Int = 200,
    val recentPRs: List<Pair<String, Int>> = emptyList(),
    // Gap
    val gapRunning: Boolean = false,
    val gapPlayBars: Int = 4,
    val gapMuteBars: Int = 1,
    // Session timer
    val timerRunning: Boolean = false,
    val timerStartMs: Long = 0L,
    val timerAccMs: Long = 0L,
    val focus: String = "",
    // Warm-up
    val lastWarm: String = "",
    // Battle
    val battleState: String = "idle",   // idle | prep | round | rest | done
    val battleRunning: Boolean = false,
    val battleRound: Int = 1,
    val battleRounds: Int = 2,
    val battleLen: Int = 90,
    val battleRest: Int = 30,
    val battlePrep: Int = 5,
    val battleLeft: Int = 0,
    // Drill
    val drillPlan: DrillBuilder.DrillPlan? = null,
    val drillIndex: Int = 0,
    val drillRunning: Boolean = false,
    val drillPaused: Boolean = false,
    val drillBlockLeftSec: Int = 0,
    val drillSeed: Int = 0,
    val drillTargetMin: Int = 30,
)

@HiltViewModel
class TrainerViewModel @Inject constructor(
    private val metronome: MetronomeEngine,
    private val repo: EntryRepository,
    private val settings: SettingsRepository
) : ViewModel() {

    private val _state = MutableStateFlow(TrainerUiState())
    val uiState: StateFlow<TrainerUiState> = _state.asStateFlow()

    private var battleJob: Job? = null
    private var drillJob: Job? = null

    init {
        // Sync BPM from metronome engine
        viewModelScope.launch {
            metronome.beatFlow.collect { _state.update { s -> s.copy(bpm = metronome.bpm) } }
        }
        // Load settings
        viewModelScope.launch {
            settings.lastWarm.collect { lw -> _state.update { it.copy(lastWarm = lw) } }
        }
    }

    // ── Speed ramp ────────────────────────────────────────────────────────────

    fun startRamp() {
        val s = _state.value
        metronome.rampEnabled   = true
        metronome.rampEveryBars = s.rampEveryBars
        metronome.rampStepBpm   = s.rampStepBpm
        metronome.rampMaxBpm    = s.rampMaxBpm
        metronome.gapEnabled    = false
        if (!metronome.isRunning) metronome.start()
        _state.update { it.copy(rampRunning = true) }
    }

    fun stopRamp() {
        metronome.rampEnabled = false
        metronome.stop()
        _state.update { it.copy(rampRunning = false) }
    }

    fun resetBpm() { metronome.setBpm(_state.value.bpm); _state.update { it.copy(bpm = metronome.bpm) } }
    /** Logs current BPM as a practice session BPM record. */
    fun markCeiling() {
        viewModelScope.launch {
            repo.logSession(PracticeLogEntity(
                type  = "practice",
                day   = java.time.LocalDate.now().toString(),
                minutes = 0,
                focus = "BPM ceiling mark",
                bpm   = metronome.bpm
            ))
            // Track the PR in the state list
            val pr = "BPM ${metronome.bpm}" to metronome.bpm
            _state.update { it.copy(recentPRs = (listOf(pr) + it.recentPRs).take(8)) }
        }
    }
    fun setRampBars(v: Int) = _state.update { it.copy(rampEveryBars = v.coerceIn(1, 16)) }
    fun setRampStep(v: Int) = _state.update { it.copy(rampStepBpm = v.coerceIn(1, 10)) }
    fun setRampMax(v: Int)  = _state.update { it.copy(rampMaxBpm = v.coerceIn(80, 300)) }

    // ── Gap mode ──────────────────────────────────────────────────────────────

    fun startGap() {
        val s = _state.value
        metronome.gapEnabled  = true
        metronome.gapPlayBars = s.gapPlayBars
        metronome.gapMuteBars = s.gapMuteBars
        metronome.rampEnabled = false
        if (!metronome.isRunning) metronome.start()
        _state.update { it.copy(gapRunning = true) }
    }

    fun stopGap() {
        metronome.gapEnabled = false
        metronome.stop()
        _state.update { it.copy(gapRunning = false) }
    }

    fun setGapPlay(v: Int)  = _state.update { it.copy(gapPlayBars = v.coerceIn(1, 16)) }
    fun setGapMute(v: Int)  = _state.update { it.copy(gapMuteBars = v.coerceIn(1, 16)) }
    fun setGapPreset(play: Int, mute: Int) = _state.update { it.copy(gapPlayBars = play, gapMuteBars = mute) }

    // ── Session timer ─────────────────────────────────────────────────────────

    fun startTimer() {
        _state.update { it.copy(timerRunning = true, timerStartMs = System.currentTimeMillis()) }
    }

    fun pauseTimer() {
        val s = _state.value
        val acc = s.timerAccMs + (System.currentTimeMillis() - s.timerStartMs)
        _state.update { it.copy(timerRunning = false, timerAccMs = acc) }
    }

    fun setFocus(v: String) = _state.update { it.copy(focus = v) }

    fun finishSession() {
        val s = _state.value
        val elapsed = s.timerAccMs + if (s.timerRunning) System.currentTimeMillis() - s.timerStartMs else 0L
        val mins = (elapsed / 60_000).toInt()
        if (mins < 1) return
        viewModelScope.launch {
            repo.logSession(PracticeLogEntity(
                type    = "practice",
                day     = LocalDate.now().toString(),
                minutes = mins,
                focus   = s.focus,
                bpm     = metronome.bpm
            ))
            _state.update { it.copy(timerRunning = false, timerAccMs = 0L, timerStartMs = 0L, focus = "") }
        }
    }

    fun discardSession() = _state.update { it.copy(timerRunning = false, timerAccMs = 0L, timerStartMs = 0L) }

    // ── Warm-up ───────────────────────────────────────────────────────────────

    fun recordWarmUp() {
        val now = java.time.ZonedDateTime.now().toString()
        viewModelScope.launch { settings.setLastWarm(now) }
        _state.update { it.copy(lastWarm = now) }
    }

    // ── Battle mode ───────────────────────────────────────────────────────────

    fun battleStart() {
        battleStop()
        val s = _state.value
        _state.update { it.copy(battleRunning = true, battleState = "prep",
            battleLeft = s.battlePrep, battleRound = 1) }
        battleJob = viewModelScope.launch {
            while (isActive) {
                delay(1000)
                val cur = _state.value
                val newLeft = cur.battleLeft - 1
                if (newLeft <= 0) {
                    when (cur.battleState) {
                        "prep" -> _state.update { it.copy(battleState = "round", battleLeft = cur.battleLen) }
                        "round" -> {
                            if (cur.battleRound >= cur.battleRounds) {
                                _state.update { it.copy(battleState = "done", battleRunning = false) }
                                logBattle(cur)
                                break
                            } else if (cur.battleRest > 0) {
                                _state.update { it.copy(battleState = "rest", battleLeft = cur.battleRest, battleRound = cur.battleRound + 1) }
                            } else {
                                _state.update { it.copy(battleState = "round", battleLeft = cur.battleLen, battleRound = cur.battleRound + 1) }
                            }
                        }
                        "rest" -> _state.update { it.copy(battleState = "round", battleLeft = cur.battleLen) }
                    }
                } else {
                    _state.update { it.copy(battleLeft = newLeft) }
                }
            }
        }
    }

    fun battleStop() {
        battleJob?.cancel()
        drillJob?.cancel(); battleJob = null
        _state.update { it.copy(battleRunning = false, battleState = "idle", battleLeft = 0, battleRound = 1) }
    }

    fun logBattleSession() { logBattle(_state.value) }

    private fun logBattle(s: TrainerUiState) {
        viewModelScope.launch {
            repo.logSession(PracticeLogEntity(
                type = "battle", day = LocalDate.now().toString(),
                minutes = ((s.battleLen * s.battleRounds) / 60).coerceAtLeast(1),
                focus = "Battle rounds", rounds = s.battleRounds, roundLength = s.battleLen
            ))
        }
    }

    fun setBattleFormat(len: Int, rounds: Int, rest: Int) {
        battleStop()
        _state.update { it.copy(battleLen = len, battleRounds = rounds, battleRest = rest) }
    }

    fun setBattleLen(v: Int)    = _state.update { it.copy(battleLen = v.coerceIn(15, 600)) }
    fun setBattleRounds(v: Int) = _state.update { it.copy(battleRounds = v.coerceIn(1, 10)) }
    fun setBattleRest(v: Int)   = _state.update { it.copy(battleRest = v.coerceIn(0, 180)) }
    fun setBattlePrep(v: Int)   = _state.update { it.copy(battlePrep = v.coerceIn(0, 30)) }

    
    // ── Drill system ──────────────────────────────────────────────────────────

    fun setDrillMinutes(m: Int) {
        _state.update { it.copy(drillTargetMin = m.coerceIn(15, 90)) }
    }

    fun buildDrill(seed: Int = _state.value.drillSeed) {
        viewModelScope.launch {
            val entries = repo.observeAll().first()
            // Build a simple file-count map (0 if no files yet tracked in this call)
            val fileCounts = entries.associate { it.id to 0 }
            val lastWarm = try { settings.lastWarm.first() } catch (_: Exception) { "" }
            val plan = DrillBuilder.build(
                minutes = _state.value.drillTargetMin,
                seed = seed,
                allEntries = entries,
                fileCounts = fileCounts,
                lastWarmIso = lastWarm.ifBlank { null }
            )
            _state.update {
                it.copy(
                    drillPlan = plan,
                    drillIndex = 0,
                    drillRunning = false,
                    drillPaused = false,
                    drillBlockLeftSec = 0,
                    drillSeed = seed
                )
            }
        }
    }

    fun rebuildDrill() = buildDrill(_state.value.drillSeed + 1)

    fun startDrill() {
        val plan = _state.value.drillPlan ?: return
        if (plan.blocks.isEmpty()) return
        applyDrillBlock(0)
        _state.update { it.copy(drillRunning = true, drillPaused = false, drillIndex = 0) }
        runDrillTicker()
    }

    fun pauseDrill() {
        drillJob?.cancel()
        _state.update { it.copy(drillPaused = true) }
    }

    fun resumeDrill() {
        _state.update { it.copy(drillPaused = false) }
        runDrillTicker()
    }

    fun nextDrillBlock() {
        val s = _state.value
        val plan = s.drillPlan ?: return
        val next = s.drillIndex + 1
        if (next >= plan.blocks.size) {
            finishDrill()
        } else {
            applyDrillBlock(next)
            _state.update { it.copy(drillIndex = next) }
        }
    }

    fun finishDrill() {
        drillJob?.cancel()
        val s = _state.value
        val plan = s.drillPlan
        viewModelScope.launch {
            repo.logSession(PracticeLogEntity(
                type = "drill",
                day = LocalDate.now().toString(),
                minutes = plan?.totalMinutes ?: s.drillTargetMin,
                focus = "Drill ${plan?.totalMinutes ?: s.drillTargetMin}min"
            ))
        }
        _state.update {
            it.copy(
                drillRunning = false,
                drillPaused = false,
                drillBlockLeftSec = 0,
                drillIndex = 0
            )
        }
        metronome.stop()
    }

    fun abandonDrill() {
        drillJob?.cancel()
        metronome.stop()
        _state.update {
            it.copy(drillRunning = false, drillPaused = false, drillBlockLeftSec = 0)
        }
    }

    private fun applyDrillBlock(index: Int) {
        val plan = _state.value.drillPlan ?: return
        val block = plan.blocks.getOrNull(index) ?: return
        if (block.bpm > 0) {
            metronome.setBpm(block.bpm)
            if (block.click && !metronome.isRunning) metronome.start()
            if (!block.click) metronome.stop()
        } else {
            metronome.stop()
        }
        _state.update {
            it.copy(
                drillBlockLeftSec = block.minutes * 60,
                bpm = if (block.bpm > 0) block.bpm else it.bpm
            )
        }
    }

    private fun runDrillTicker() {
        drillJob?.cancel()
        drillJob = viewModelScope.launch {
            while (_state.value.drillRunning && !_state.value.drillPaused) {
                delay(1000)
                val left = _state.value.drillBlockLeftSec - 1
                if (left <= 0) {
                    nextDrillBlock()
                } else {
                    _state.update { it.copy(drillBlockLeftSec = left) }
                }
            }
        }
    }


    override fun onCleared() {
        battleJob?.cancel()
        drillJob?.cancel()
        // Metronome stays running after leaving Trainer (same as HTML behaviour)
    }
}
