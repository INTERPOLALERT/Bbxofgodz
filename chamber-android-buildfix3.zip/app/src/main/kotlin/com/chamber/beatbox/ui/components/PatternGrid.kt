package com.chamber.beatbox.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.chamber.beatbox.data.audio.SequencerEngine
import com.chamber.beatbox.ui.theme.*

/**
 * Step sequencer grid.
 *
 * Rendered inside EntryScreen when entry.kind == "pattern".
 *
 * Layout:
 *   [LANE LABEL] [step0] [step1] ... [stepN] [MUTE]
 *
 * On a 390dp screen (iPhone 14 width), at 16 steps:
 *   available = 390 - 14*2 (padding) - 52 (label) - 36 (mute) = 274dp
 *   cell = 274/16 = 17dp — tight but tappable with a slightly larger hit area
 *
 * 8-step layout is more comfortable; user can toggle via resolution button.
 */
@Composable
fun PatternGrid(
    grid: Map<String, BooleanArray>,
    currentStep: Int,
    muted: Set<String>,
    onToggleCell: (lane: String, step: Int) -> Unit,
    onToggleMute: (lane: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val c = LocalChamberColors.current
    val steps = grid.values.firstOrNull()?.size ?: 16
    // Cell width scales down for larger step counts
    val cellSize: Dp = when {
        steps <= 8  -> 34.dp
        steps <= 16 -> 20.dp
        else        -> 14.dp
    }
    val labelW = 54.dp
    val muteW  = 38.dp

    Column(modifier.fillMaxWidth()) {
        // Beat markers (1, 2, 3, 4...)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.width(labelW))
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                for (step in 0 until steps) {
                    val beatNum = step / (steps / 4) + 1
                    val isBeat = step % (steps / 4) == 0
                    Box(
                        Modifier.width(cellSize),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isBeat) Text(
                            beatNum.toString(),
                            style = ChamberType.MonoTiny,
                            color = c.muted
                        )
                    }
                }
            }
            Spacer(Modifier.width(muteW))
        }

        // Lane rows
        SequencerEngine.LANES.forEach { lane ->
            val laneGrid = grid[lane] ?: BooleanArray(steps)
            val isMuted = lane in muted

            Row(
                Modifier.fillMaxWidth().padding(vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Lane label
                Text(
                    lane.take(3).uppercase(),
                    style    = ChamberType.MonoLabel,
                    color    = if (isMuted) c.muted.copy(alpha = 0.4f) else c.muted,
                    modifier = Modifier.width(labelW)
                )

                // Steps — horizontally scrollable so 32/64-step grids still work
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    for (step in 0 until steps) {
                        val active     = laneGrid.getOrElse(step) { false }
                        val isCurrent  = step == currentStep
                        val isBarStart = step % (steps / 4) == 0

                        val bgColor = when {
                            isMuted && active -> c.muted.copy(alpha = 0.3f)
                            active && isCurrent -> c.ink
                            active  -> c.ink.copy(alpha = 0.85f)
                            isCurrent -> c.muted.copy(alpha = 0.4f)
                            else    -> Color.Transparent
                        }
                        val borderColor = when {
                            isBarStart -> c.ink
                            else       -> c.ink.copy(alpha = 0.5f)
                        }

                        Box(
                            Modifier
                                .size(cellSize)
                                .border(
                                    width = if (isBarStart) ChamberDimens.BorderWidth else 1.dp,
                                    color = borderColor
                                )
                                .background(bgColor)
                                .clickable { onToggleCell(lane, step) }
                        )
                    }
                }

                Spacer(Modifier.width(6.dp))

                // Mute button
                Box(
                    Modifier
                        .width(muteW)
                        .height(cellSize)
                        .border(1.dp, c.ink.copy(alpha = if (isMuted) 0.4f else 1f))
                        .background(if (isMuted) Color.Transparent else c.ink)
                        .clickable { onToggleMute(lane) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (isMuted) "M" else "M",
                        style = ChamberType.MonoTiny,
                        color = if (isMuted) c.muted.copy(alpha = 0.4f) else c.bg
                    )
                }
            }
        }
    }
}

/**
 * Full Pattern editor widget — includes grid + transport controls + BPM/resolution/swing.
 * Drop this into EntryScreen for kind == "pattern".
 */
@Composable
fun PatternEditor(
    entryId: String,
    vm: PatternEditorViewModel = hiltViewModel<PatternEditorViewModel, PatternEditorViewModel.Factory> { it.create(entryId) }
) {
    val c = LocalChamberColors.current
    val grid by vm.grid.collectAsState()
    val currentStep by vm.currentStep.collectAsState()
    val muted by vm.mutedLanes.collectAsState()
    val isPlaying by vm.isPlaying.collectAsState()
    val bpm by vm.bpm.collectAsState()
    val steps by vm.stepCount.collectAsState()
    val swing by vm.swing.collectAsState()

    Column(Modifier.fillMaxWidth()) {
        SectionLine("Pattern Sequencer")
        Spacer(Modifier.height(8.dp))

        // Transport row
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically) {
            ChamberButton(if (isPlaying) "■ STOP" else "▶ PLAY",
                onClick = { vm.togglePlay() },
                size = ButtonSize.Normal, modifier = Modifier.weight(1f))
            ChamberButton("CLEAR", onClick = { vm.clearAll() }, size = ButtonSize.Small)
        }
        Spacer(Modifier.height(6.dp))

        // BPM + steps row
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically) {
            // BPM control
            Box(Modifier.border(ChamberDimens.BorderWidth, c.ink).clickable { vm.setBpm(bpm - 5) }
                .padding(horizontal = 12.dp, vertical = 8.dp)) {
                Text("−", style = ChamberType.ButtonSm, color = c.ink)
            }
            Text("$bpm BPM", style = ChamberType.MonoLabel, color = c.ink,
                modifier = Modifier.weight(1f))
            Box(Modifier.border(ChamberDimens.BorderWidth, c.ink).clickable { vm.setBpm(bpm + 5) }
                .padding(horizontal = 12.dp, vertical = 8.dp)) {
                Text("+", style = ChamberType.ButtonSm, color = c.ink)
            }

            Spacer(Modifier.width(8.dp))

            // Steps toggle: 8 / 16 / 32
            listOf(8, 16, 32).forEach { n ->
                val active = n == steps
                Box(Modifier.border(ChamberDimens.BorderWidth, c.ink)
                    .background(if (active) c.ink else c.bg)
                    .clickable { vm.setStepCount(n) }
                    .padding(horizontal = 8.dp, vertical = 8.dp)) {
                    Text(n.toString(), style = ChamberType.ButtonSm,
                        color = if (active) c.bg else c.ink)
                }
            }
        }

        // Swing slider (text-based for simplicity)
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("SWING ${(swing * 100).toInt()}%", style = ChamberType.MonoLabel, color = c.muted,
                modifier = Modifier.width(90.dp))
            listOf(0f to "OFF", 0.33f to "LIGHT", 0.6f to "MED", 0.85f to "HARD").forEach { (v, label) ->
                val active = Math.abs(swing - v) < 0.1f
                Box(Modifier.border(1.dp, c.ink).background(if (active) c.ink else c.bg)
                    .clickable { vm.setSwing(v) }.padding(horizontal = 7.dp, vertical = 6.dp)) {
                    Text(label, style = ChamberType.MonoTiny, color = if (active) c.bg else c.ink)
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        // The grid itself
        PatternGrid(
            grid = grid,
            currentStep = currentStep,
            muted = muted,
            onToggleCell = { lane, step -> vm.toggleCell(lane, step) },
            onToggleMute = { lane -> vm.toggleMute(lane) }
        )
    }
}
