package com.chamber.beatbox.ui.screens.entry

import android.Manifest
import android.media.MediaPlayer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.chamber.beatbox.data.audio.RecorderEngine
import com.chamber.beatbox.data.db.entities.EntryEntity
import com.chamber.beatbox.data.db.entities.FileMetaEntity
import com.chamber.beatbox.ui.components.*
import com.chamber.beatbox.ui.components.PatternEditor
import com.chamber.beatbox.ui.navigation.Routes
import com.chamber.beatbox.ui.theme.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

// ── Field definitions ─────────────────────────────────────────────────────────

private data class FieldDef(val key: String, val label: String, val type: String, val opts: List<String> = emptyList())

private val CHAMP_STATUS   = listOf("Idea","Developing","Solid","Battle-Ready","Retired","Completed")
private val IDEA_STATUS    = listOf("Raw idea","Developing","Solid","Shelved")
private val SOCIAL_STATUS  = listOf("Idea","Scripted","Filmed","Editing","Posted","Archived")
private val GOAL_STATUS    = listOf("Active","Paused","Completed","Dropped")
private val SESSION_STATUS = listOf("Planned","Done","Skipped")
private val SIGS           = listOf("4/4","3/4","6/8","5/4","7/8","2/4")
private val ROUNDS         = listOf("Top 8","Top 16","Top 32","Wildcard","Exhibition","Team")
private val PLATFORMS      = listOf("Instagram","TikTok","YouTube","Twitter/X","Facebook","Snapchat","Other")

private val FIELDS: Map<String, List<FieldDef>> = mapOf(
    "champ"     to listOf(FieldDef("round","Round","select",ROUNDS),FieldDef("status","Training status","select",CHAMP_STATUS),FieldDef("bpm","BPM","num"),FieldDef("description","Description","ta"),FieldDef("tags","Tags","tags"),FieldDef("techniques","Techniques used","tags"),FieldDef("genres","Genres / influences","tags"),FieldDef("performance","Performance notes","ta"),FieldDef("strengths","Strengths","ta"),FieldDef("weaknesses","Weaknesses","ta"),FieldDef("improve","Things to improve","ta"),FieldDef("notes","Notes","ta")),
    "idea"      to listOf(FieldDef("status","Development status","select",IDEA_STATUS),FieldDef("bpm","BPM","num"),FieldDef("mood","Mood","text"),FieldDef("genre","Genre","tags"),FieldDef("techniques","Techniques","tags"),FieldDef("inspiration","Inspiration","ta"),FieldDef("description","Description","ta"),FieldDef("notes","Notes","ta")),
    "bars"      to listOf(FieldDef("bpm","BPM","num"),FieldDef("sig","Time signature","select",SIGS),FieldDef("genre","Genre","tags"),FieldDef("technique","Technique","tags"),FieldDef("description","Description","ta"),FieldDef("notes","Notes","ta")),
    "oneshot"   to listOf(FieldDef("bpm","BPM","num"),FieldDef("category","Category","select",listOf("bass","drums","musicality","sfx","transition","other")),FieldDef("description","Description","ta"),FieldDef("tags","Tags","tags"),FieldDef("notes","Notes","ta")),
    "technique" to listOf(FieldDef("bpm","Working BPM","num"),FieldDef("dateLearned","Date learned","date"),FieldDef("description","Description","ta"),FieldDef("related","Related techniques","tags"),FieldDef("relgenres","Related genres","tags"),FieldDef("exercises","Training exercises","ta"),FieldDef("notes","Notes / what needs improvement","ta")),
    "genre"     to listOf(FieldDef("bpmRange","BPM range","text"),FieldDef("artists","Favourite artists / beatboxers","ta"),FieldDef("techniques","Techniques used","tags"),FieldDef("patterns","Patterns","ta"),FieldDef("rhythms","Rhythms","ta"),FieldDef("inspiration","Inspiration","ta"),FieldDef("notes","Notes","ta")),
    "social"    to listOf(FieldDef("platform","Platform","select",PLATFORMS),FieldDef("status","Status","select",SOCIAL_STATUS),FieldDef("datePlanned","Date planned","date"),FieldDef("datePosted","Date posted","date"),FieldDef("hook","Hook","text"),FieldDef("caption","Caption idea","ta"),FieldDef("results","Performance / results","ta"),FieldDef("notes","Notes","ta")),
    "vocode"    to listOf(FieldDef("bpm","BPM","num"),FieldDef("effect","Effect used","text"),FieldDef("settings","Settings / notes","ta"),FieldDef("beforeafter","Before / after notes","ta"),FieldDef("future","Ideas for future use","ta"),FieldDef("notes","Notes","ta")),
    "goal"      to listOf(FieldDef("status","Status","select",GOAL_STATUS),FieldDef("deadline","Deadline","date"),FieldDef("progress","Progress %","num"),FieldDef("description","Description","ta"),FieldDef("notes","Notes","ta")),
    "session"   to listOf(FieldDef("status","Status","select",SESSION_STATUS),FieldDef("notes","Notes","ta")),
    "pattern"   to listOf(FieldDef("bpm","BPM","num"),FieldDef("genre","Genre","tags"),FieldDef("technique","Techniques used","tags"),FieldDef("feel","Feel / swing notes","text"),FieldDef("notes","Notes","ta")),
    "setlist"   to listOf(FieldDef("event","Event / occasion","text"),FieldDef("date","Date","date"),FieldDef("status","Status","select",listOf("Draft","Locked","Performed")),FieldDef("notes","Notes","ta"))
)

private val RATINGS: Map<String, List<Pair<String,String>>> = mapOf(
    "technique" to listOf("difficulty" to "Difficulty","confidence" to "Confidence","speed" to "Speed","cleanliness" to "Cleanliness","musicality" to "Musicality"),
    "bars"      to listOf("performance" to "Performance rating"),
    "pattern"   to listOf("groove" to "Groove rating"),
    "session"   to listOf("quality" to "Session rating")
)

// ═════════════════════════════════════════════════════════════════════════════

@Composable
fun EntryScreen(
    entryId: String,
    nav: NavHostController,
    vm: EntryViewModel = hiltViewModel<EntryViewModel, EntryViewModel.Factory> { it.create(entryId) }
) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val entry = state.entry
    val c = LocalChamberColors.current

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.startRecording()
    }

    if (state.showLinkPicker) {
        LinkPickerSheet(
            allEntries = state.allEntriesForPicker,
            linkedIds  = EntryViewModel.parseJsonStringArray(entry.links),
            onToggle   = { vm.toggleLink(it) },
            onDismiss  = { vm.hideLinkPicker() }
        )
        return
    }

    LazyColumn(Modifier.fillMaxSize().background(c.bg),
        contentPadding = PaddingValues(ChamberDimens.ContentPaddingH)) {

        // Header
        item {
            Spacer(Modifier.height(ChamberDimens.ContentPaddingV))
            Row(Modifier.fillMaxWidth().border(ChamberDimens.BorderThick, c.ink).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text(glyphForKind(entry.kind, entry.cat), style = ChamberType.Glyph, color = c.ink,
                    modifier = Modifier.padding(end = 12.dp))
                Column(Modifier.weight(1f)) {
                    Text(entry.kind.uppercase(), style = ChamberType.MonoLabel, color = c.muted)
                    var nameEdit by remember(entry.id) { mutableStateOf(entry.name) }
                    LaunchedEffect(entry.name) { if (entry.name != nameEdit) nameEdit = entry.name }
                    ChamberField(nameEdit, { nameEdit = it; vm.updateName(it) }, placeholder = "Name…",
                        textStyle = ChamberType.Title.copy(fontWeight = FontWeight.ExtraBold),
                        modifier = Modifier.padding(top = 4.dp))
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        // Actions
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                entry.bpm?.let { ChamberButton("♩ $it BPM", onClick = { vm.loadBpmToMetronome() }, size = ButtonSize.Small) }
                ChamberButton(if (entry.pin) "UNPIN" else "📌 PIN", onClick = { vm.togglePin() }, size = ButtonSize.Small)
                ChamberButton("DUPLICATE", onClick = {
                    vm.duplicate { newId -> nav.navigate("e/$newId") { popUpTo(nav.graph.startDestinationId) } }
                }, size = ButtonSize.Small)
                Spacer(Modifier.weight(1f))
                ChamberButton("TRASH", onClick = { vm.trash { nav.navigateUp() } }, size = ButtonSize.Small, style = ButtonStyle.Danger)
            }
            Spacer(Modifier.height(8.dp))
        }

        // Kind-specific fields
        FIELDS[entry.kind]?.forEach { field ->
            item(key = "field_${field.key}") {
                KindField(field, entry.bpm, entry.status, state.extra, vm)
                Spacer(Modifier.height(2.dp))
            }
        }

        // Pattern sequencer (pattern kind only)
        if (entry.kind == "pattern") {
            item(key = "sequencer") {
                PatternEditor(entryId = entryId)
                Spacer(Modifier.height(8.dp))
            }
        }

        // Ratings
        RATINGS[entry.kind]?.takeIf { it.isNotEmpty() }?.let { keys ->
            item {
                SectionLine("Ratings")
                Spacer(Modifier.height(8.dp))
                keys.forEach { (key, label) ->
                    RatingBlock(label, vm.lastRating(key)) { vm.addRating(key, it) }
                    Spacer(Modifier.height(6.dp))
                }
            }
        }

        // Champ checklist + review
        if (entry.kind == "champ") {
            item {
                SectionLine("Checklist")
                Spacer(Modifier.height(8.dp))
                val items = vm.checklistItems()
                if (items.isEmpty()) {
                    HintBox("Break the routine into steps: Opening, Main, Drop, Transitions…")
                }
                items.forEachIndexed { i, (label, done) ->
                    Row(
                        Modifier.fillMaxWidth().border(2.dp, c.ink)
                            .clickable { vm.toggleChecklistItem(i) }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (done) "☑" else "☐", style = ChamberType.BodyBold, color = c.ink, modifier = Modifier.width(32.dp))
                        Text(label, style = ChamberType.BodyBold, color = if (done) c.muted else c.ink, modifier = Modifier.weight(1f))
                        Text("✕", style = ChamberType.MonoLabel, color = c.muted,
                            modifier = Modifier.clickable { vm.removeChecklistItem(i) }.padding(8.dp))
                    }
                    Spacer(Modifier.height(2.dp))
                }
                var newItem by remember { mutableStateOf("") }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    ChamberField(newItem, { newItem = it }, placeholder = "Add step…", modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(6.dp))
                    ChamberButton("ADD", onClick = {
                        vm.addChecklistItem(newItem); newItem = ""
                    }, size = ButtonSize.Small)
                }
                Spacer(Modifier.height(14.dp))

                SectionLine("Post-performance review")
                Spacer(Modifier.height(8.dp))
                listOf(
                    "worked" to "What worked?",
                    "didnt" to "What didn't?",
                    "audience" to "Audience reaction?",
                    "judging" to "Judging notes?"
                ).forEach { (key, label) ->
                    Text(label.uppercase(), style = ChamberType.MonoLabel, color = c.muted)
                    Spacer(Modifier.height(4.dp))
                    var val_ by remember(entry.id, key) { mutableStateOf(vm.reviewField(key)) }
                    ChamberField(val_, {
                        val_ = it
                        vm.updateReviewField(key, it)
                    }, placeholder = label, multiline = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                }
            }
        }



        // Files + Recording
        item {
            SectionLine("Files", count = state.files.size)
            Spacer(Modifier.height(8.dp))
            RecordingWidget(
                state  = state,
                onStart = {
                    if (vm.hasMicPermission()) vm.startRecording()
                    else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                },
                onPause   = { vm.pauseRecording() },
                onResume  = { vm.resumeRecording() },
                onSave    = { vm.stopAndSaveRecording() },
                onDiscard = { vm.discardRecording() }
            )
        }
        items(state.files, key = { it.id }) { file ->
            AudioFileRow(
                file      = file,
                isPlaying = state.playingFileId == file.id,
                onPlayToggle = { vm.setPlayingFile(if (state.playingFileId == file.id) null else file.id) },
                onDelete  = { vm.deleteFile(file.id) },
                onTrim    = { start, end, done -> vm.trimAudio(file.id, start, end, done) }
            )
        }

        // Linked entries
        item {
            Spacer(Modifier.height(8.dp))
            SectionLine("Linked Entries", count = state.linkedEntries.size)
            Spacer(Modifier.height(6.dp))
        }
        items(state.linkedEntries, key = { it.id }) { linked ->
            ChamberRow(
                name = linked.name.ifBlank { "Untitled" },
                meta = "${linked.kind.uppercase()}${linked.bpm?.let { " · $it BPM" } ?: ""}",
                glyph = glyphForKind(linked.kind, linked.cat),
                modifier = Modifier.clickable { nav.navigate(Routes.entry(linked.id)) }
            )
            Spacer(Modifier.height(2.dp))
        }
        item {
            ChamberButton("+ LINK ENTRY", onClick = { vm.showLinkPicker() },
                size = ButtonSize.Small, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
        }

        // Log history
        if (state.log.isNotEmpty()) {
            item { SectionLine("Log History", count = state.log.size) }
            items(state.log.takeLast(20).reversed(), key = { it.t }) { log ->
                LogRow(log)
            }
        }

        // Footer
        item {
            Spacer(Modifier.height(16.dp))
            Text("CREATED ${fmtDate(entry.createdAt)} · UPDATED ${fmtDate(entry.updatedAt)}",
                style = ChamberType.Mono, color = c.muted)
            Spacer(Modifier.height(ChamberDimens.BottomPadding))
        }
    }
}

// ═════════════════════════════════════════════════════════════════════════════
// Recording widget
// ═════════════════════════════════════════════════════════════════════════════

@Composable
private fun RecordingWidget(
    state: EntryUiState,
    onStart: () -> Unit, onPause: () -> Unit, onResume: () -> Unit,
    onSave: () -> Unit, onDiscard: () -> Unit
) {
    val c = LocalChamberColors.current
    val isIdle      = state.recorderState is RecorderEngine.State.Idle
    val isRecording = state.recorderState is RecorderEngine.State.Recording
    val isPaused    = state.recorderState is RecorderEngine.State.Paused
    val isActive    = isRecording || isPaused

    if (!isActive) {
        ChamberButton("⏺ RECORD AUDIO", onClick = onStart, modifier = Modifier.fillMaxWidth())
    } else {
        Column(Modifier.fillMaxWidth().border(ChamberDimens.BorderThick, Red).padding(10.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                // Blinking dot
                val alpha by produceState(1f) {
                    while (true) { value = if (isRecording) 1f else 0.3f; kotlinx.coroutines.delay(500); value = 0.3f; kotlinx.coroutines.delay(500) }
                }
                Text("●", style = ChamberType.Brand, color = Red.copy(alpha = if(isRecording) alpha else 0.4f))
                Text(
                    "  ${fmtDur(state.recordingMs)}  ${if (isRecording) "RECORDING" else "PAUSED"}",
                    style = ChamberType.MonoLabel, color = if (isRecording) Red else c.muted,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (isRecording) {
                    ChamberButton("❚❚ PAUSE", onClick = onPause, size = ButtonSize.Small, modifier = Modifier.weight(1f))
                } else {
                    ChamberButton("▶ RESUME", onClick = onResume, size = ButtonSize.Small, modifier = Modifier.weight(1f))
                }
                ChamberButton("■ SAVE", onClick = onSave, size = ButtonSize.Small, modifier = Modifier.weight(1f))
                ChamberButton("✕", onClick = onDiscard, size = ButtonSize.Small, style = ButtonStyle.Danger)
            }
        }
    }
    Spacer(Modifier.height(6.dp))
}

// ═════════════════════════════════════════════════════════════════════════════
// Audio file row with MediaPlayer
// ═════════════════════════════════════════════════════════════════════════════

@Composable
private fun AudioFileRow(
    file: FileMetaEntity,
    isPlaying: Boolean,
    onPlayToggle: () -> Unit,
    onDelete: () -> Unit,
    onTrim: (startMs: Long, endMs: Long, onDone: (Boolean) -> Unit) -> Unit = { _, _, d -> d(false) }
) {
    val c = LocalChamberColors.current
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var progress by remember { mutableStateOf(0f) }
    var playerReady by remember { mutableStateOf(false) }
    var showTrim by remember { mutableStateOf(false) }
    val duration = remember(file.id) {
        file.duration.takeIf { it > 0 } ?: com.chamber.beatbox.data.audio.AudioTrimmer.durationMs(file.path)
    }
    val wave = remember(file.id) {
        com.chamber.beatbox.data.audio.AudioTrimmer.sampleWaveform(file.path, 48)
    }
    var startFrac by remember { mutableStateOf(0f) }
    var endFrac by remember { mutableStateOf(1f) }
    var trimming by remember { mutableStateOf(false) }
    var trimMsg by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            if (player == null) {
                val mp = MediaPlayer()
                runCatching {
                    mp.setDataSource(file.path)
                    mp.prepare()
                    mp.start()
                    mp.setOnCompletionListener { onPlayToggle() }
                    player = mp
                    playerReady = true
                }.onFailure { mp.release() }
            } else {
                player?.start()
            }
        } else {
            player?.pause()
        }
    }
    LaunchedEffect(isPlaying, playerReady) {
        while (isPlaying && player != null) {
            val mp = player ?: break
            val dur = mp.duration.takeIf { it > 0 } ?: break
            progress = mp.currentPosition.toFloat() / dur
            kotlinx.coroutines.delay(250)
        }
    }
    DisposableEffect(file.id) {
        onDispose { player?.release(); player = null }
    }

    Column(Modifier.fillMaxWidth().border(ChamberDimens.BorderWidth, c.ink).padding(10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(36.dp).border(ChamberDimens.BorderWidth, c.ink)
                    .background(if (isPlaying) c.ink else c.bg)
                    .clickable(onClick = onPlayToggle),
                contentAlignment = Alignment.Center
            ) {
                Text(if (isPlaying) "❚❚" else "▶", style = ChamberType.MonoTiny,
                    color = if (isPlaying) c.bg else c.ink)
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(file.name, style = ChamberType.BodyBold, color = c.ink)
                Text(
                    "${fmtSize(file.size)}${if (duration > 0) " · ${fmtDur(duration)}" else ""}",
                    style = ChamberType.Mono, color = c.muted
                )
            }
            if (duration > 500) {
                ChamberButton("TRIM", size = ButtonSize.ExtraSmall, onClick = { showTrim = !showTrim })
                Spacer(Modifier.width(4.dp))
            }
            ChamberButton("✕", size = ButtonSize.ExtraSmall, style = ButtonStyle.Danger, onClick = onDelete)
        }
        if (isPlaying || progress > 0f) {
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth().height(3.dp).border(1.dp, c.ink)) {
                Box(Modifier.fillMaxWidth(progress).fillMaxHeight().background(c.ink))
            }
        }

        if (showTrim && duration > 0) {
            Spacer(Modifier.height(10.dp))
            Text("TRIM AUDIO", style = ChamberType.MonoLabel, color = c.muted)
            Spacer(Modifier.height(6.dp))
            // Waveform
            Canvas(Modifier.fillMaxWidth().height(48.dp).border(1.dp, c.ink)) {
                val n = wave.size
                val barW = size.width / n
                val startX = startFrac * size.width
                val endX = endFrac * size.width
                // dim outside selection
                drawRect(c.ink.copy(alpha = 0.08f), size = size)
                wave.forEachIndexed { i, amp ->
                    val h = amp * size.height * 0.9f
                    val x = i * barW
                    val selected = x + barW / 2 >= startX && x <= endX
                    drawRect(
                        if (selected) c.ink else c.ink.copy(alpha = 0.25f),
                        topLeft = androidx.compose.ui.geometry.Offset(x + 1f, (size.height - h) / 2),
                        size = androidx.compose.ui.geometry.Size(barW - 2f, h)
                    )
                }
                // handles
                drawLine(Color(0xFFCC0000), androidx.compose.ui.geometry.Offset(startX, 0f),
                    androidx.compose.ui.geometry.Offset(startX, size.height), 3.dp.toPx())
                drawLine(Color(0xFFCC0000), androidx.compose.ui.geometry.Offset(endX, 0f),
                    androidx.compose.ui.geometry.Offset(endX, size.height), 3.dp.toPx())
            }
            Spacer(Modifier.height(8.dp))
            Text("START  ${fmtDur((startFrac * duration).toLong())}", style = ChamberType.Mono, color = c.muted)
            // Simple step buttons for start/end (no Material Slider dependency issues)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                ChamberButton("−1s", size = ButtonSize.ExtraSmall, onClick = {
                    startFrac = (startFrac - 1000f / duration).coerceIn(0f, endFrac - 0.02f)
                })
                ChamberButton("+1s", size = ButtonSize.ExtraSmall, onClick = {
                    startFrac = (startFrac + 1000f / duration).coerceIn(0f, endFrac - 0.02f)
                })
                Spacer(Modifier.weight(1f))
                ChamberButton("−1s", size = ButtonSize.ExtraSmall, onClick = {
                    endFrac = (endFrac - 1000f / duration).coerceIn(startFrac + 0.02f, 1f)
                })
                ChamberButton("+1s", size = ButtonSize.ExtraSmall, onClick = {
                    endFrac = (endFrac + 1000f / duration).coerceIn(startFrac + 0.02f, 1f)
                })
            }
            Text("END  ${fmtDur((endFrac * duration).toLong())}", style = ChamberType.Mono, color = c.muted)
            Spacer(Modifier.height(8.dp))
            val selMs = ((endFrac - startFrac) * duration).toLong()
            Text("SELECTION · ${fmtDur(selMs)}", style = ChamberType.MonoLabel, color = c.ink)
            Spacer(Modifier.height(6.dp))
            ChamberButton(
                if (trimming) "TRIMMING…" else "SAVE TRIM AS NEW FILE",
                onClick = {
                    if (trimming) return@ChamberButton
                    trimming = true
                    trimMsg = null
                    onTrim((startFrac * duration).toLong(), (endFrac * duration).toLong()) { ok ->
                        trimming = false
                        trimMsg = if (ok) "Trim saved as new file" else "Trim failed"
                        if (ok) showTrim = false
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
            trimMsg?.let {
                Spacer(Modifier.height(4.dp))
                Text(it, style = ChamberType.Mono, color = c.muted)
            }
        }
    }
    Spacer(Modifier.height(2.dp))
}

// ═════════════════════════════════════════════════════════════════════════════
// Link picker — full-screen modal over the entry
// ═════════════════════════════════════════════════════════════════════════════

@Composable
private fun LinkPickerSheet(
    allEntries: List<EntryEntity>,
    linkedIds: List<String>,
    onToggle: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val c = LocalChamberColors.current
    var filter by remember { mutableStateOf("") }
    var kindFilter by remember { mutableStateOf("") }

    val filtered = allEntries.filter { e ->
        (filter.isBlank() || e.name.contains(filter, ignoreCase = true)) &&
        (kindFilter.isBlank() || e.kind == kindFilter)
    }.sortedWith(compareBy({ it.kind }, { it.name }))

    val kinds = allEntries.map { it.kind }.distinct().sorted()

    Column(Modifier.fillMaxSize().background(c.bg)) {
        // Header
        Row(Modifier.fillMaxWidth().border(ChamberDimens.BorderThick, c.ink).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("Link Entries", style = ChamberType.Brand, color = c.ink, modifier = Modifier.weight(1f))
            Text("${linkedIds.size} linked", style = ChamberType.MonoLabel, color = c.muted)
            Spacer(Modifier.width(12.dp))
            ChamberButton("DONE", onClick = onDismiss, size = ButtonSize.Small)
        }

        // Search filter
        Row(Modifier.fillMaxWidth().border(ChamberDimens.BorderWidth, c.ink).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("⌕ ", style = ChamberType.Body, color = c.muted)
            BasicTextField(filter, { filter = it }, textStyle = ChamberType.Body.copy(color = c.ink),
                cursorBrush = SolidColor(c.ink), singleLine = true, modifier = Modifier.weight(1f),
                decorationBox = { inner ->
                    if (filter.isEmpty()) Text("Filter by name…", style = ChamberType.Body, color = c.muted)
                    inner()
                })
        }

        // Kind filter chips
        if (kinds.size > 1) {
            Row(Modifier.fillMaxWidth()
                .horizontalScroll(androidx.compose.foundation.rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                val kindOptions = listOf("" to "ALL") + kinds.map { k -> k to k.uppercase() }
                kindOptions.forEach { (kind, label) ->
                    val active = kindFilter == kind
                    Box(Modifier.border(1.dp, c.ink).background(if(active) c.ink else c.bg)
                        .clickable { kindFilter = kind }.padding(horizontal = 8.dp, vertical = 4.dp)) {
                        Text(label, style = ChamberType.MonoTiny, color = if(active) c.bg else c.ink)
                    }
                }
            }
        }

        // Entry list
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(8.dp)) {
            if (filtered.isEmpty()) {
                item { HintBox(if (filter.isBlank()) "No entries to link." else "No results for \"$filter\".") }
            }
            items(filtered, key = { it.id }) { e ->
                val linked = e.id in linkedIds
                Row(
                    Modifier.fillMaxWidth()
                        .border(ChamberDimens.BorderWidth, if(linked) c.ink else c.ink.copy(alpha = 0.4f))
                        .background(if (linked) c.ink else c.bg)
                        .clickable { onToggle(e.id) }
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (linked) "✓" else " ", style = ChamberType.BodyBold,
                        color = if (linked) c.bg else c.ink, modifier = Modifier.width(28.dp))
                    Text(glyphForKind(e.kind, e.cat), style = ChamberType.Body,
                        color = if (linked) c.bg else c.muted, modifier = Modifier.width(32.dp))
                    Column(Modifier.weight(1f)) {
                        Text(e.name.ifBlank { "Untitled" }, style = ChamberType.BodyBold,
                            color = if (linked) c.bg else c.ink)
                        Text(e.kind.uppercase(), style = ChamberType.MonoTiny,
                            color = if (linked) c.bg.copy(alpha = 0.7f) else c.muted)
                    }
                    e.bpm?.let {
                        Text("$it BPM", style = ChamberType.MonoTiny,
                            color = if (linked) c.bg.copy(alpha = 0.7f) else c.muted)
                    }
                }
                Spacer(Modifier.height(2.dp))
            }
            item { Spacer(Modifier.height(ChamberDimens.BottomPadding)) }
        }
    }
}

// ═════════════════════════════════════════════════════════════════════════════
// Field renderers (unchanged from before)
// ═════════════════════════════════════════════════════════════════════════════

@Composable
private fun KindField(field: FieldDef, bpm: Int?, status: String?, extra: Map<String,String>, vm: EntryViewModel) {
    when {
        field.key == "bpm" -> {
            var v by remember(bpm) { mutableStateOf(bpm?.toString() ?: "") }
            ChamberField(v, { v = it; vm.updateBpm(it) }, label = field.label, placeholder = "e.g. 140", modifier = Modifier.fillMaxWidth())
        }
        field.key == "status" && field.type == "select" ->
            SelectField(field, status ?: field.opts.firstOrNull() ?: "") { vm.updateStatus(it) }
        field.type == "select" ->
            SelectField(field, extra[field.key] ?: field.opts.firstOrNull() ?: "") { vm.updateExtraField(field.key, it) }
        field.type == "tags" || field.key in setOf("tags","techniques","genre","genres","related","relgenres","technique") -> {
            val current = EntryViewModel.parseJsonStringArray(extra[field.key] ?: "[]")
            TagsField(field, current) { vm.updateTagField(field.key, it) }
        }
        field.type == "ta" -> {
            var v by remember(field.key, extra[field.key].orEmpty().take(10)) { mutableStateOf(extra[field.key] ?: "") }
            ChamberField(v, { v = it; vm.updateExtraField(field.key, it) }, label = field.label, multiline = true, modifier = Modifier.fillMaxWidth())
        }
        else -> {
            var v by remember(field.key) { mutableStateOf(extra[field.key] ?: "") }
            ChamberField(v, { v = it; vm.updateExtraField(field.key, it) }, label = field.label,
                placeholder = if (field.type == "date") "YYYY-MM-DD" else "…", modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun SelectField(field: FieldDef, current: String, onSelect: (String) -> Unit) {
    val c = LocalChamberColors.current
    var expanded by remember { mutableStateOf(false) }
    Column {
        Text(field.label.uppercase(), style = ChamberType.FieldLabel, color = c.muted, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp))
        Box(Modifier.fillMaxWidth().border(ChamberDimens.BorderWidth, c.ink).background(c.bg).clickable { expanded = !expanded }.padding(10.dp)) {
            Text(current.ifEmpty { field.opts.firstOrNull() ?: "—" }, style = ChamberType.Body, color = c.ink)
        }
        if (expanded) {
            Column(Modifier.fillMaxWidth().border(ChamberDimens.BorderWidth, c.ink).background(c.bg)) {
                field.opts.forEach { opt ->
                    Text(opt, style = ChamberType.Body, color = if (opt == current) c.bg else c.ink,
                        modifier = Modifier.fillMaxWidth().background(if (opt == current) c.ink else c.bg).clickable { onSelect(opt); expanded = false }.padding(10.dp))
                }
            }
        }
    }
}

@Composable
private fun TagsField(field: FieldDef, current: List<String>, onChange: (List<String>) -> Unit) {
    val c = LocalChamberColors.current
    var inputVal by remember { mutableStateOf("") }
    Column {
        Text(field.label.uppercase(), style = ChamberType.FieldLabel, color = c.muted, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp))
        if (current.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                current.forEach { tag ->
                    Row(Modifier.border(ChamberDimens.BorderWidth, c.ink).padding(horizontal = 9.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(tag, style = ChamberType.MonoLabel, color = c.ink)
                        Text(" ✕", style = ChamberType.MonoLabel, color = c.muted, modifier = Modifier.clickable { onChange(current - tag) })
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            ChamberField(inputVal, { inputVal = it }, placeholder = "Add…", modifier = Modifier.weight(1f))
            Spacer(Modifier.width(6.dp))
            ChamberButton("+", size = ButtonSize.Small, onClick = {
                if (inputVal.isNotBlank() && !current.contains(inputVal.trim())) { onChange(current + inputVal.trim()); inputVal = "" }
            })
        }
    }
}

@Composable
private fun RatingBlock(label: String, current: Int?, onRate: (Int) -> Unit) {
    val c = LocalChamberColors.current
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label.uppercase(), style = ChamberType.FieldLabel, color = c.muted, modifier = Modifier.width(130.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            (1..5).forEach { n ->
                val filled = current != null && n <= current
                Box(Modifier.size(36.dp).border(ChamberDimens.BorderWidth, c.ink).background(if (filled) c.ink else c.bg).clickable { onRate(n) })
            }
        }
        if (current != null) Text("  $current/5", style = ChamberType.Mono, color = c.muted)
    }
}

@Composable
private fun LogRow(log: LogEntry) {
    val c = LocalChamberColors.current
    Row(Modifier.fillMaxWidth().border(ChamberDimens.BorderWidth, c.ink).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(log.d, style = ChamberType.Mono, color = c.muted, modifier = Modifier.width(80.dp))
        Text(log.k.uppercase(), style = ChamberType.MonoLabel, color = c.muted, modifier = Modifier.width(110.dp))
        Text(log.v, style = ChamberType.BodyBold, color = c.ink)
    }
}

// ═════════════════════════════════════════════════════════════════════════════
// Helpers (extension on Modifier for bottom border)
// ═════════════════════════════════════════════════════════════════════════════

private fun glyphForKind(kind: String, cat: String?) = when {
    kind == "technique" -> when (cat) { "musicality"->"MUS"; "tonguebass"->"TB"; "sfx"->"SFX"; "singing"->"SNG"; else->"TEC" }
    else -> when (kind) { "champ"->"+"; "idea"->"!"; "bars"->"▤"; "oneshot"->"1"; "genre"->"♫"; "social"->"@"; "vocode"->"≈"; "goal"->"◎"; "session"->"▸"; "pattern"->"▦"; "setlist"->"≡"; else->"·" }
}
private fun fmtDate(t: Long): String = SimpleDateFormat("d MMM yy", Locale.ENGLISH).format(Date(t))
private fun fmtSize(b: Long): String = if (b > 1_048_576) "%.1f MB".format(b/1_048_576f) else "${(b/1024).coerceAtLeast(1)} KB"
private fun fmtDur(ms: Long): String = "${ms/60_000}:${"%02d".format((ms/1000)%60)}"
