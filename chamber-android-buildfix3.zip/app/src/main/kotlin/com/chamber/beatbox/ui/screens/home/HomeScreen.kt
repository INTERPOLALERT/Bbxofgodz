package com.chamber.beatbox.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.chamber.beatbox.data.db.entities.EntryEntity
import com.chamber.beatbox.ui.components.*
import com.chamber.beatbox.ui.navigation.Routes
import com.chamber.beatbox.ui.theme.*

/**
 * Mirrors HTML renderHome() section order:
 * head → tiles → event → today's quests → drill card → due for review →
 * pinned → start something → this week → continue
 */
@Composable
fun HomeScreen(
    nav: NavHostController,
    vm: HomeViewModel = hiltViewModel()
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val c = LocalChamberColors.current

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            horizontal = ChamberDimens.ContentPaddingH,
            vertical = ChamberDimens.ContentPaddingV
        )
    ) {
        // Header — HTML uses "Chamber" + date subtitle
        item {
            val dayStr = java.text.SimpleDateFormat("EEEE, d MMMM", java.util.Locale.ENGLISH)
                .format(java.util.Date()).uppercase()
            SectionHead(
                glyph = "⌂",
                title = "Chamber",
                subtitle = dayStr,
                modifier = Modifier.padding(bottom = 14.dp)
            )
        }

        // Tiles: LEVEL · DAY STREAK · MINUTES LOGGED · RECORDINGS
        item {
            Row(Modifier.fillMaxWidth()) {
                StatTile(state.level.toString(), "LEVEL · ${state.rank}",
                    onClick = { nav.navigate(Routes.QUESTS) }, modifier = Modifier.weight(1f))
                StatTile(state.streak.toString(), "DAY STREAK",
                    onClick = { nav.navigate(Routes.STATS) }, modifier = Modifier.weight(1f))
                StatTile(state.totalMinutes.toString(), "MINUTES LOGGED",
                    onClick = { nav.navigate(Routes.STATS) }, modifier = Modifier.weight(1f))
                StatTile(state.fileCount.toString(), "RECORDINGS",
                    onClick = { nav.navigate(Routes.GODMODE) }, modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
        }

        // Event countdown / set competition
        item {
            if (state.eventDate.isNotBlank() && state.eventDaysLeft != null) {
                val days = state.eventDaysLeft!!
                val label = when {
                    days > 0 -> "$days DAY${if (days == 1) "" else "S"} TO GO"
                    days == 0 -> "TODAY"
                    else -> "PASSED"
                }
                Column(Modifier.fillMaxWidth().border(2.dp, c.ink).padding(12.dp)) {
                    Text(
                        "${(state.eventName.ifBlank { "EVENT" }).uppercase()} — $label",
                        style = ChamberType.BodyBold, color = c.ink
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        state.eventDate.take(10) + if (days > 0)
                            " · ${kotlin.math.max(1, (days + 6) / 7)} weeks of preparation left" else "",
                        style = ChamberType.Mono, color = c.muted
                    )
                }
            } else {
                ChamberButton(
                    "+ SET YOUR NEXT COMPETITION DATE",
                    onClick = { nav.navigate(Routes.DATA) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.height(12.dp))
        }

        // Today's quests
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("TODAY'S QUESTS", style = ChamberType.SectionLine, color = c.ink)
                Text(
                    "${state.dailyQuestDone}/${state.dailyQuestTotal.coerceAtLeast(state.dailyQuests.size)}",
                    style = ChamberType.MonoLabel, color = c.muted
                )
            }
            Spacer(Modifier.height(8.dp))
        }
        items(state.dailyQuests, key = { it.id }) { q ->
            Row(
                Modifier.fillMaxWidth().border(2.dp, c.ink)
                    .background(if (q.done) c.ink else c.bg)
                    .clickable { nav.navigate(Routes.QUESTS) }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(if (q.done) "✓" else "★", style = ChamberType.BodyBold,
                    color = if (q.done) c.bg else c.ink, modifier = Modifier.width(28.dp))
                Text(q.title, style = ChamberType.BodyBold,
                    color = if (q.done) c.bg else c.ink, modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.height(2.dp))
        }
        item {
            Spacer(Modifier.height(6.dp))
            ChamberButton(
                "ALL QUESTS · BADGES · BOSS →",
                onClick = { nav.navigate(Routes.QUESTS) },
                size = ButtonSize.Small,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
        }

        // Today's drill card
        item {
            Column(Modifier.fillMaxWidth().border(2.dp, c.ink).padding(12.dp)) {
                Text(
                    "TODAY'S DRILL — ${state.drillMinutes} MIN",
                    style = ChamberType.BodyBold, color = c.ink
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Built from your weakest ratings, untouched genres and the tempos you avoid.",
                    style = ChamberType.Mono, color = c.muted
                )
                Spacer(Modifier.height(8.dp))
                ChamberButton(
                    "BUILD IT →",
                    onClick = { nav.navigate(Routes.DRILL) },
                    size = ButtonSize.Small
                )
            }
            Spacer(Modifier.height(12.dp))
        }

        // Due for review
        if (state.reviewDue.isNotEmpty()) {
            item {
                SectionLine("DUE FOR REVIEW", count = state.reviewDue.size)
                Spacer(Modifier.height(6.dp))
            }
            items(state.reviewDue, key = { "rev_${it.id}" }) { e ->
                HomeEntryRow(e) { nav.navigate(Routes.entry(e.id)) }
            }
            item { Spacer(Modifier.height(8.dp)) }
        }

        // Pinned
        if (state.pinned.isNotEmpty()) {
            item {
                SectionLine("PINNED")
                Spacer(Modifier.height(6.dp))
            }
            items(state.pinned, key = { "pin_${it.id}" }) { e ->
                HomeEntryRow(e) { nav.navigate(Routes.entry(e.id)) }
            }
            item { Spacer(Modifier.height(8.dp)) }
        }

        // Start something — same tiles as HTML
        item {
            SectionLine("START SOMETHING")
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                listOf(
                    Triple("●", "QUICK CAPTURE", Routes.IDEAS),
                    Triple("DRL", "DRILL", Routes.DRILL),
                    Triple("◉", "VISUALIZER", Routes.VIZ),
                    Triple("⏱", "TRAINER", Routes.TRAINER)
                ).forEach { (g, l, r) ->
                    StatTile(g, l, onClick = { nav.navigate(r) }, modifier = Modifier.weight(1f))
                }
            }
            Row(Modifier.fillMaxWidth()) {
                listOf(
                    Triple("⚔", "BATTLE", Routes.BATTLE),
                    Triple("★", "QUESTS", Routes.QUESTS),
                    Triple("∑", "STATS", Routes.STATS),
                    Triple("G", "GODMODE", Routes.GODMODE)
                ).forEach { (g, l, r) ->
                    StatTile(g, l, onClick = { nav.navigate(r) }, modifier = Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        // This week strip
        item {
            SectionLine("THIS WEEK")
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth().border(2.dp, c.ink).padding(8.dp)) {
                state.weekMinutes.forEach { (label, mins) ->
                    Column(
                        Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            if (mins > 0) mins.toString() else "·",
                            style = ChamberType.BodyBold, color = c.ink
                        )
                        Text(label.takeLast(2), style = ChamberType.MonoTiny, color = c.muted)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        // Continue
        if (state.recentEntries.isNotEmpty()) {
            item {
                SectionLine("CONTINUE")
                Spacer(Modifier.height(6.dp))
            }
            items(state.recentEntries, key = { "rec_${it.id}" }) { e ->
                HomeEntryRow(e) { nav.navigate(Routes.entry(e.id)) }
            }
        }

        item { Spacer(Modifier.height(ChamberDimens.BottomPadding)) }
    }
}

@Composable
private fun HomeEntryRow(entry: EntryEntity, onClick: () -> Unit) {
    val c = LocalChamberColors.current
    val meta = buildList {
        entry.status?.let { add(it.uppercase()) }
        entry.bpm?.let { add("$it BPM") }
        entry.cat?.let { add(it.uppercase()) }
        val s = (System.currentTimeMillis() - entry.updatedAt) / 1000
        add(when {
            s < 60 -> "NOW"
            s < 3600 -> "${s / 60}M AGO"
            s < 86400 -> "${s / 3600}H AGO"
            else -> "${s / 86400}D AGO"
        })
    }.joinToString(" · ")
    Column(
        Modifier.fillMaxWidth().border(2.dp, c.ink).clickable(onClick = onClick).padding(12.dp)
    ) {
        Text(entry.name.ifBlank { "Untitled" }, style = ChamberType.BodyBold, color = c.ink)
        Text(meta, style = ChamberType.Mono, color = c.muted)
    }
    Spacer(Modifier.height(0.dp)) // HTML stack: rows touch via -2px; we keep 0 for clarity
}
