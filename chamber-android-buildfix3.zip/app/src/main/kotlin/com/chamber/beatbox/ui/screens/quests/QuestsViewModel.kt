package com.chamber.beatbox.ui.screens.quests

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chamber.beatbox.data.db.dao.GameStateDao
import com.chamber.beatbox.data.db.entities.GameStateEntity
import com.chamber.beatbox.data.repository.EntryRepository
import com.chamber.beatbox.data.repository.SettingsRepository
import com.chamber.beatbox.data.badges.BadgeEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import javax.inject.Inject
import kotlin.math.min

data class QuestDef(
    val id: String, val title: String, val xp: Int, val icon: String,
    val isBoss: Boolean = false,
    val checkFn: suspend (QuestContext) -> Boolean = { false }
)

data class QuestContext(
    val todayMinutes: Int,
    val yesterdayMinutes: Int,
    val weekMinutes: Int,
    val todayNewEntries: Int,
    val todayNewIdeas: Int,
    val todayNewTechniques: Int,
    val todayNewBars: Int,
    val streakDays: Int,
    val sessionCount: Int,
    val topBpmEver: Int,
    val lastWarmToday: Boolean
)

data class QuestState(val defId: String, val done: Boolean, val completedAt: Long? = null, val title: String? = null)

data class QuestsUiState(
    val xp: Int = 0,
    val level: Int = 1,
    val rank: String = "NOVICE",
    val xpToNext: Int = 30,
    val xpProgress: Float = 0f,
    val daily: List<Pair<QuestDef, QuestState>> = emptyList(),
    val boss: Pair<QuestDef, QuestState>? = null,
    val badges: List<String> = emptyList(),
    val weekKey: String = ""
)

@HiltViewModel
class QuestsViewModel @Inject constructor(
    private val gameStateDao: GameStateDao,
    private val repo: EntryRepository,
    private val settings: SettingsRepository
) : ViewModel() {

    val uiState: StateFlow<QuestsUiState> = gameStateDao.observe()
        .filterNotNull()
        .map { buildUiState(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), QuestsUiState())

    init { viewModelScope.launch { ensureQuestsRolled(); evaluateBadges() } }

    // ── Check + award XP ─────────────────────────────────────────────────────

    /** HTML MARK DONE — manual complete, awards XP even if auto-check would fail. */
    fun checkQuest(questId: String) {
        viewModelScope.launch {
            val gs  = gameStateDao.get() ?: return@launch
            val def = ALL_QUESTS.find { it.id == questId } ?: return@launch

            val states = parseStates(gs.questJson).toMutableMap()
            if (states[questId]?.done == true) return@launch
            states[questId] = QuestState(questId, true, System.currentTimeMillis(), states[questId]?.title)

            gameStateDao.upsert(gs.copy(
                xp        = gs.xp + def.xp,
                questJson = encodeStates(states, weekKey()),
                updatedAt = System.currentTimeMillis()
            ))
            evaluateBadges()
        }
    }

    
    // ── Badges ────────────────────────────────────────────────────────────────

    fun evaluateBadges() {
        viewModelScope.launch {
            val gs = gameStateDao.get() ?: GameStateEntity()
            val already = runCatching {
                Json.parseToJsonElement(gs.badgesJson).jsonArray.mapNotNull { it.jsonPrimitive.contentOrNull }
            }.getOrElse { emptyList() }.toSet()

            val entries = repo.observeAll().first()
            val sessions = repo.observeRecentSessions(500).first()
            val kindCounts = entries.groupingBy { it.kind }.eachCount()
            val allDays = repo.allPracticeDays().toSet()
            val streak = computeStreak(allDays)
            val totalMins = repo.totalPracticeMinutes()
            val topBpm = repo.highestBpmLoggedEver()
            val fileCount = 0 // enriched later if needed

            val ctx = BadgeEngine.BadgeContext(
                entries = entries,
                sessions = sessions,
                fileCount = fileCount,
                streak = streak,
                totalMinutes = totalMins,
                topBpm = topBpm,
                kindCounts = kindCounts,
                hasRecording = sessions.any { it.focus.contains("record", true) } || entries.any { true }, // approx
                hasPattern = (kindCounts["pattern"] ?: 0) > 0,
                hasChamp = (kindCounts["champ"] ?: 0) > 0,
                genreCount = kindCounts["genre"] ?: 0
            )

            val newly = BadgeEngine.evaluate(ctx, already)
            if (newly.isNotEmpty()) {
                val updated = (already + newly).toList()
                val arr = buildJsonArray { updated.forEach { add(it) } }
                gameStateDao.upsert(gs.copy(
                    badgesJson = arr.toString(),
                    xp = gs.xp + newly.size * 15, // small XP bonus per badge
                    updatedAt = System.currentTimeMillis()
                ))
            }
        }
    }

    fun awardXp(amount: Int) {
        viewModelScope.launch {
            val gs = gameStateDao.get() ?: GameStateEntity()
            gameStateDao.upsert(gs.copy(xp = gs.xp + amount, updatedAt = System.currentTimeMillis()))
        }
    }

    // ── Weekly roll ───────────────────────────────────────────────────────────

    private suspend fun ensureQuestsRolled() {
        val gs   = gameStateDao.get() ?: GameStateEntity()
        val week = weekKey()
        val existingWeek = runCatching {
            Json.parseToJsonElement(gs.questJson).jsonObject["weekKey"]?.jsonPrimitive?.content
        }.getOrNull()
        if (existingWeek == week) return

        val ctxBits = buildDynamicBits()
        val daily = ALL_QUESTS.filter { !it.isBoss }.shuffled().take(3)
        val boss  = ALL_QUESTS.filter { it.isBoss }.randomOrNull() ?: ALL_QUESTS.filter { it.isBoss }.first()
        val states = buildMap<String, QuestState> {
            daily.forEach { def ->
                put(def.id, QuestState(def.id, false, title = personalize(def.title, ctxBits)))
            }
            put(boss.id, QuestState(boss.id, false, title = personalize(boss.title, ctxBits)))
        }
        gameStateDao.upsert(gs.copy(questJson = encodeStates(states, week), updatedAt = System.currentTimeMillis()))
    }

    // ── Context — real Room data ──────────────────────────────────────────────

    private suspend fun buildContext(): QuestContext {
        val today     = LocalDate.now().toString()
        val yesterday = LocalDate.now().minusDays(1).toString()
        val monday    = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).toString()

        val allDays   = repo.allPracticeDays().toSet()
        val daily     = repo.dailyMinutesSince(monday)
        val todayMins = daily.find { it.day == today }?.minutes ?: 0
        val yestMins  = daily.find { it.day == yesterday }?.minutes ?: 0
        val weekMins  = daily.sumOf { it.minutes }

        return QuestContext(
            todayMinutes       = todayMins,
            yesterdayMinutes   = yestMins,
            weekMinutes        = weekMins,
            todayNewEntries    = repo.countEntriesCreatedToday(),
            todayNewIdeas      = repo.countByKindCreatedToday("idea"),
            todayNewTechniques = repo.countByKindCreatedToday("technique"),
            todayNewBars       = repo.countByKindCreatedToday("bars"),
            streakDays         = computeStreak(allDays),
            sessionCount       = allDays.size,
            topBpmEver         = repo.highestBpmLoggedEver(),
            lastWarmToday      = run {
                val lw = kotlinx.coroutines.flow.first(settings.lastWarm)
                lw.isNotBlank() && lw.startsWith(java.time.LocalDate.now().toString())
            }
        )
    }

    private suspend fun buildUiState(gs: GameStateEntity): QuestsUiState {
        val states  = parseStates(gs.questJson)
        val questIds = states.keys.toList()

        val daily = questIds
            .mapNotNull { id -> ALL_QUESTS.find { it.id == id && !it.isBoss } }
            .take(3)
            .map { def -> def to (states[def.id] ?: QuestState(def.id, false)) }

        val bossId = questIds.firstOrNull { id -> ALL_QUESTS.find { it.id == id }?.isBoss == true }
        val boss   = bossId?.let { id ->
            val def = ALL_QUESTS.find { it.id == id } ?: return@let null
            def to (states[id] ?: QuestState(id, false))
        }

        val lvl   = levelOf(gs.xp)
        val xpThis = xpForLevel(lvl)
        val xpNext = xpForLevel(lvl + 1)
        val prog  = if (xpNext > xpThis) (gs.xp - xpThis).toFloat() / (xpNext - xpThis) else 1f

        val badges = runCatching {
            Json.parseToJsonElement(gs.badgesJson).jsonArray.mapNotNull { it.jsonPrimitive.contentOrNull }
        }.getOrElse { emptyList() }

        return QuestsUiState(
            xp         = gs.xp,
            level      = lvl,
            rank       = rankOf(lvl),
            xpToNext   = (xpNext - gs.xp).coerceAtLeast(0),
            xpProgress = prog.coerceIn(0f, 1f),
            daily      = daily,
            boss       = boss,
            badges     = badges,
            weekKey    = weekKey()
        )
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    private fun weekKey(): String = LocalDate.now()
        .with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).toString()

    private fun computeStreak(days: Set<String>): Int {
        var streak = 0; var check = LocalDate.now()
        while (days.contains(check.toString())) { streak++; check = check.minusDays(1) }
        return streak
    }

    private fun parseStates(questJson: String): Map<String, QuestState> = runCatching {
        val obj    = Json.parseToJsonElement(questJson).jsonObject
        val arr    = obj["states"]?.jsonArray ?: return@runCatching emptyMap()
        arr.associate { el ->
            val o  = el.jsonObject
            val id = o["id"]!!.jsonPrimitive.content
            id to QuestState(id, o["done"]?.jsonPrimitive?.boolean ?: false,
                o["completedAt"]?.jsonPrimitive?.longOrNull,
                o["title"]?.jsonPrimitive?.contentOrNull)
        }
    }.getOrElse { emptyMap() }

    private fun encodeStates(states: Map<String, QuestState>, weekKey: String): String =
        buildJsonObject {
            put("weekKey", weekKey)
            putJsonArray("states") {
                states.values.forEach { s ->
                    addJsonObject {
                        put("id", s.defId); put("done", s.done)
                        s.completedAt?.let { put("completedAt", it) }
                        s.title?.let { put("title", it) }
                    }
                }
            }
        }.toString()


    private data class DynamicBits(
        val genre: String,
        val technique: String,
        val bpm: Int,
        val bars: Int,
        val oneshotIdea: String
    )

    private suspend fun buildDynamicBits(): DynamicBits {
        val entries = repo.observeAll().first()
        val genres = entries.filter { it.kind == "genre" && !it.deleted }.map { it.name }.filter { it.isNotBlank() }
        val techs = entries.filter { it.kind == "technique" && !it.deleted }.map { it.name }.filter { it.isNotBlank() }
        val fallbackGenres = listOf("Drum & Bass", "Hip-Hop", "Trap", "Garage", "Jungle", "Footwork", "Grime", "Boom Bap")
        val fallbackTech = listOf("throat bass", "lip roll", "click roll", "inward bass", "vocal scratch", "rimshot", "hi-hat roll")
        val genre = (genres + fallbackGenres).random()
        val technique = (techs + fallbackTech).random()
        val bpm = listOf(85, 90, 100, 110, 128, 140, 160, 174, 180).random()
        val bars = listOf(4, 8, 16).random()
        val oneshot = listOf("reverse cymbal", "vocal riser", "mouth siren", "throat sweep", "lip pop chain", "breath stab").random()
        return DynamicBits(genre, technique, bpm, bars, oneshot)
    }

    private fun personalize(template: String, bits: DynamicBits): String {
        return template
            .replace("{genre}", bits.genre)
            .replace("{technique}", bits.technique)
            .replace("{bpm}", bits.bpm.toString())
            .replace("{bars}", bits.bars.toString())
            .replace("{oneshot}", bits.oneshotIdea)
    }


    /** HTML autoVerify — mark quests done when checkFn already true. */
    fun autoVerify() {
        viewModelScope.launch {
            ensureQuestsRolled()
            val ctx = buildContext()
            val gs = gameStateDao.get() ?: return@launch
            val states = parseStates(gs.questJson).toMutableMap()
            var changed = false
            for ((id, st) in states) {
                if (st.done) continue
                val def = ALL_QUESTS.find { it.id == id } ?: continue
                if (def.checkFn(ctx)) {
                    states[id] = st.copy(done = true, completedAt = System.currentTimeMillis())
                    // award XP
                    val xp = (gs.xp) + def.xp
                    gameStateDao.upsert(gs.copy(xp = xp, questJson = encodeStates(states, weekKey()), updatedAt = System.currentTimeMillis()))
                    changed = true
                    break // re-read after write
                }
            }
            if (changed) {
                // second pass for remaining
                val gs2 = gameStateDao.get() ?: return@launch
                val states2 = parseStates(gs2.questJson).toMutableMap()
                var xp2 = gs2.xp
                for ((id, st) in states2) {
                    if (st.done) continue
                    val def = ALL_QUESTS.find { it.id == id } ?: continue
                    if (def.checkFn(buildContext())) {
                        states2[id] = st.copy(done = true, completedAt = System.currentTimeMillis())
                        xp2 += def.xp
                    }
                }
                gameStateDao.upsert(gs2.copy(xp = xp2, questJson = encodeStates(states2, weekKey()), updatedAt = System.currentTimeMillis()))
            }
        }
    }

    companion object {
        fun xpForLevel(l: Int)   = 30 * (l - 1) * l
        fun levelOf(xp: Int): Int { var l = 1; while (xp >= xpForLevel(l + 1) && l < 99) l++; return l }
        private val RANKS = listOf("NOVICE","ROOKIE","APPRENTICE","JOURNEYMAN","SKILLED","ADEPT",
            "PROFICIENT","EXPERT","MASTER","GRANDMASTER","CHAMPION","ELITE","LEGEND","MYTHIC","TRANSCENDENT")
        fun rankOf(level: Int)   = RANKS[min(RANKS.size - 1, level - 1)]

        val ALL_QUESTS: List<QuestDef> = listOf(
            // ── Practice time ──────────────────────────────────────────────
            QuestDef("t1","Log a 30-min practice session", 20, "⏱") { it.todayMinutes >= 30 },
            QuestDef("t2","Log a 60-min practice session", 35, "⏱") { it.todayMinutes >= 60 },
            QuestDef("t3","Log a 90-min practice session", 50, "⏱") { it.todayMinutes >= 90 },
            QuestDef("t4","Beat yesterday's practice time", 25, "⚡") { it.todayMinutes > it.yesterdayMinutes && it.todayMinutes > 0 },
            // ── Entry creation ─────────────────────────────────────────────
            QuestDef("t5","Capture a new idea for {genre}", 10, "!") { it.todayNewIdeas >= 1 },
            QuestDef("t6","Write a {bars}-bar exercise",   15, "▤") { it.todayNewBars >= 1 },
            QuestDef("t7","Log work on {technique}",       15, "TEC") { it.todayNewTechniques >= 1 },
            QuestDef("t8","Add 3 entries in one day",      25, "▦") { it.todayNewEntries >= 3 },
            // ── Streaks ────────────────────────────────────────────────────
            QuestDef("t9","Maintain a 3-day streak",       30, "🔥") { it.streakDays >= 3 },
            QuestDef("t10","Maintain a 7-day streak",      60, "🔥") { it.streakDays >= 7 },
            QuestDef("t11","Practice 5 days this week",    50, "⭐") { it.streakDays >= 5 },
            // ── Combined ───────────────────────────────────────────────────
            QuestDef("t12","Practice AND add an entry",    20, "◉") { it.todayMinutes > 0 && it.todayNewEntries > 0 },
            QuestDef("t13","Log a battle session",         20, "⚔") { false },  // battle tag tracked in TrainerVM
            QuestDef("dyn1","Write a {bars}-bar beat in {genre}", 20, "▤") { it.todayNewBars >= 1 },
            QuestDef("dyn2","Record a {oneshot} as a 1-shot", 25, "◉") { it.todayMinutes >= 10 },
            QuestDef("dyn3","Push toward {bpm} BPM today",  30, "⚡") { it.topBpmEver >= 140 || it.todayMinutes >= 20 },
            QuestDef("dyn4","Practice tongue bass focus",   20, "👅") { false },
            QuestDef("t14","Run the warm-up routine",      15, "🔴") { it.lastWarmToday },
            QuestDef("t15","Practice 2 hours in one day",  70, "⏱") { it.todayMinutes >= 120 },
            QuestDef("t16","Add 2 ideas in one day",       20, "!") { it.todayNewIdeas >= 2 },
            QuestDef("t17","Create a bar exercise AND practice", 25, "▤") { it.todayNewBars >= 1 && it.todayMinutes >= 15 },
                        QuestDef("dyn5","Practice {technique} at {bpm} BPM", 25, "TEC") { it.todayMinutes >= 15 },
            QuestDef("dyn6","Make something that fits {genre}", 20, "♫") { it.todayNewEntries >= 1 },
            QuestDef("dyn7","Record 8 bars of {technique}", 30, "◉") { it.todayMinutes >= 10 },
            // ── Boss quests ─────────────────────────────────────────────────
            QuestDef("b1","Practice 5 days this week",     100,"★", isBoss=true) { it.streakDays >= 5 },
            QuestDef("b2","Log 5 hours of practice this week", 150,"⏱", isBoss=true) { it.weekMinutes >= 300 },
            QuestDef("b3","Add entries to 3 different sections", 80,"▤", isBoss=true) { it.todayNewEntries >= 3 },
            QuestDef("b4","Practice every day this week",  200,"★", isBoss=true) { it.streakDays >= 7 },
            QuestDef("b5","Log a 2-hour session",          120,"⏱", isBoss=true) { it.todayMinutes >= 120 }
        )
    }
}
