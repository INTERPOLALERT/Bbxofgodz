package com.chamber.beatbox.data.repository

import com.chamber.beatbox.data.db.dao.*
import com.chamber.beatbox.data.db.entities.EntryEntity
import com.chamber.beatbox.data.db.entities.FileMetaEntity
import com.chamber.beatbox.data.db.entities.PracticeLogEntity
import com.chamber.beatbox.data.db.entities.HealthLogEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; isLenient = true }

/**
 * Single source of truth for all entry data.
 *
 * The repository handles:
 *   - Polymorphic entry CRUD with updatedAt stamping
 *   - Kind-specific queries that translate section config to DAO calls
 *   - File attachment lifecycle (metadata + physical file deletion)
 *   - Soft-delete / restore / purge (trash system)
 *   - Full-text search
 *
 * Domain-level operations that require cross-entity logic (e.g. generating
 * the drill plan from technique scores + genre coverage) live in the ViewModel
 * rather than the repository to avoid circular dependency on settings.
 */
@Singleton
class EntryRepository @Inject constructor(
    private val entryDao: EntryDao,
    private val fileMetaDao: FileMetaDao,
    private val practiceLogDao: PracticeLogDao,
    private val healthLogDao: HealthLogDao
) {
    // ── Entries ───────────────────────────────────────────────────────────────

    fun observeAll(): Flow<List<EntryEntity>> = entryDao.observeAll()

    fun observeByKind(kind: String): Flow<List<EntryEntity>> = entryDao.observeByKind(kind)

    fun observeTechniquesByCat(cat: String): Flow<List<EntryEntity>> =
        entryDao.observeTechniquesByCat(cat)

    fun observeBarsByCount(barCount: Int): Flow<List<EntryEntity>> =
        entryDao.observeBarsByCount(barCount)

    fun observeById(id: String): Flow<EntryEntity?> = entryDao.observeById(id)

    fun observeTrashed(): Flow<List<EntryEntity>> = entryDao.observeTrashed()

    fun observeKindCounts(): Flow<Map<String, Int>> =
        entryDao.observeKindCounts().map { list -> list.associate { it.kind to it.count } }

    suspend fun getById(id: String): EntryEntity? = entryDao.getById(id)

    suspend fun search(query: String): List<EntryEntity> =
        if (query.isBlank()) emptyList() else entryDao.search(query.trim())

    fun searchFlow(query: String): Flow<List<EntryEntity>> =
        if (query.isBlank()) flowOf(emptyList()) else entryDao.searchFlow(query.trim())

    suspend fun upsert(entry: EntryEntity) = entryDao.upsert(entry)

    suspend fun upsertAll(entries: List<EntryEntity>) = entryDao.upsertAll(entries)

    /**
     * Create a new entry with the given kind and name.
     * Applies kind-specific defaults matching the HTML's createEntry() function.
     */
    fun newEntry(kind: String, name: String, extra: Map<String, Any?> = emptyMap()): EntryEntity {
        val defaults = mutableMapOf<String, Any?>()
        // Replicate HTML's createEntry defaults exactly
        when (kind) {
            "champ"   -> { defaults["status"] = "Idea"; defaults["checklist"] = "[]"; defaults["review"] = "{}" }
            "idea"    -> { defaults["status"] = "Raw idea" }
            "session" -> { defaults["status"] = "Planned"; defaults["items"] = "[]"; defaults["date"] = todayIso() }
            "social"  -> { defaults["status"] = "Idea" }
            "goal"    -> { defaults["status"] = "Active" }
            "setlist" -> { defaults["status"] = "Draft"; defaults["date"] = todayIso() }
            "pattern" -> {
                defaults["bpm"]   = "120"
                defaults["beats"] = "4"
                defaults["bars"]  = "1"
                defaults["res"]   = "4"
                defaults["swing"] = "0"
                defaults["grid"]  = emptyGrid(16)
            }
        }
        defaults.putAll(extra.mapValues { it.value?.toString() })
        return EntryEntity(
            id         = uid(),
            kind       = kind,
            name       = name,
            bpm        = (defaults["bpm"] as? String)?.toIntOrNull(),
            status     = defaults["status"] as? String,
            cat        = defaults["cat"] as? String,
            bars       = (defaults["bars"] as? String)?.toIntOrNull()
                ?: if (kind == "bars") (extra["bars"] as? Int) else null,
            extraJson  = json.encodeToString(defaults.filterKeys { it !in listOf("bpm","status","cat","bars") })
        )
    }

    // ── Soft-delete / trash ──────────────────────────────────────────────────

    suspend fun duplicate(id: String): EntryEntity? {
        val src = entryDao.getById(id) ?: return null
        val copy = src.copy(
            id = uid(),
            name = src.name + " (copy)",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            pin = false,
            deleted = false
        )
        entryDao.upsert(copy)
        return copy
    }

    suspend fun trash(id: String) = entryDao.softDelete(id)

    suspend fun restore(id: String) = entryDao.restore(id)

    /**
     * Permanently removes an entry and all its attached files (DB rows + disk files).
     */
    suspend fun purge(id: String) {
        val files = fileMetaDao.getAll().filter { it.entryId == id }
        files.forEach { meta ->
            runCatching { File(meta.path).delete() }
            fileMetaDao.hardDelete(meta.id)
        }
        entryDao.hardDelete(id)
    }

    suspend fun purgeAllTrashed() {
        // Collect trashed IDs first, then purge each with file cleanup
        // (Can't do a single DELETE because we must remove physical files)
        entryDao.observeTrashed()
            .map { it.map { e -> e.id } }
            .let { flow ->
                var ids: List<String> = emptyList()
                flow.collect { ids = it }
                ids
            }
            .forEach { purge(it) }
        entryDao.purgeAllTrashed()
    }

    // ── Files ─────────────────────────────────────────────────────────────────

    fun observeFilesForEntry(entryId: String): Flow<List<FileMetaEntity>> =
        fileMetaDao.observeByEntry(entryId)

    fun observeFileCountForEntry(entryId: String): Flow<Int> =
        fileMetaDao.observeCountForEntry(entryId)

    fun observeTotalStorageBytes(): Flow<Long> = fileMetaDao.observeTotalSize()

    fun observeFileCount(): Flow<Int> = fileMetaDao.observeTotalCount()

    suspend fun attachFile(meta: FileMetaEntity) = fileMetaDao.upsert(meta)

    suspend fun updateFileDescription(id: String, desc: String) =
        fileMetaDao.updateDescription(id, desc)

    suspend fun deleteFile(id: String) {
        val meta = fileMetaDao.getById(id) ?: return
        runCatching { File(meta.path).delete() }
        fileMetaDao.hardDelete(id)
    }

    // ── Practice log ──────────────────────────────────────────────────────────

    fun observeRecentSessions(limit: Int = 100): Flow<List<PracticeLogEntity>> =
        practiceLogDao.observeRecent(limit)

    suspend fun logSession(log: PracticeLogEntity) = practiceLogDao.insert(log)

    suspend fun totalPracticeMinutes(): Int = practiceLogDao.totalMinutes()

    suspend fun allPracticeDays(): List<String> = practiceLogDao.allPracticeDays()

    suspend fun dailyMinutesSince(fromDay: String): List<DayMinutes> =
        practiceLogDao.dailyMinutesSince(fromDay).map { DayMinutes(it.day, it.total) }

    // ── Health log ────────────────────────────────────────────────────────────

    fun observeRecentHealth(limit: Int = 20): Flow<List<HealthLogEntity>> =
        healthLogDao.observeRecent(limit)

    suspend fun logHealth(log: HealthLogEntity) = healthLogDao.insert(log)

    // ── Utilities ─────────────────────────────────────────────────────────────

    // Technique stats
    suspend fun techniqueCatCounts(): Map<String, Int> =
        entryDao.techniqueCatCounts().associate { it.cat to it.cnt }

    suspend fun countByKind(kind: String): Int = entryDao.countByKind(kind)

    // Quest helpers
    suspend fun countEntriesCreatedToday(): Int {
        val midnight = java.time.LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        return entryDao.countCreatedSince(midnight)
    }

    suspend fun countByKindCreatedToday(kind: String): Int {
        val midnight = java.time.LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        return entryDao.countByKindCreatedSince(kind, midnight)
    }

    suspend fun highestBpmLoggedEver(): Int =
        practiceLogDao.getRecent(1000)
            .mapNotNull { it.bpm }.maxOrNull() ?: 0

    private fun uid(): String =
        System.currentTimeMillis().toString(36) + (Math.random() * 1e8).toLong().toString(36)

    private fun todayIso(): String = java.time.LocalDate.now().toString()

    private fun emptyGrid(steps: Int): String {
        // JSON representation of the step sequencer grid
        // Matches HTML: { kick:[], snare:[], hat:[], bass:[], extra:[] }
        val lanes = listOf("kick","snare","hat","bass","extra")
        val laneJson = lanes.joinToString(",") { k ->
            "\"$k\":[${(0 until steps).joinToString(",") { "false" }}]"
        }
        return "{$laneJson}"
    }
}

data class DayMinutes(val day: String, val minutes: Int)
