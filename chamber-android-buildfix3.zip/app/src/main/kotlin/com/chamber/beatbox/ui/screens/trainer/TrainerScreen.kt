package com.chamber.beatbox.ui.screens.trainer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.chamber.beatbox.ui.components.*
import com.chamber.beatbox.ui.theme.*
import kotlinx.coroutines.delay

private val TABS = listOf("DRILL","SPEED","GAP","TIMER","WARM-UP","COOL-DOWN","BATTLE")

@Composable
fun TrainerScreen(nav: NavHostController, initialTab: String = "timer",
                  vm: TrainerViewModel = hiltViewModel()) {
    val uiState by vm.uiState.collectAsStateWithLifecycle()
    var tab by remember { mutableStateOf(
        when (initialTab) { "drill" -> "DRILL"; "battle" -> "BATTLE"; "warm" -> "WARM-UP"; else -> "TIMER" }
    )}

    ChamberTheme(darkSurface = true) {
        Column(Modifier.fillMaxSize().background(BgDark)) {
            SectionHead("⏱","Trainer","DRILL · SPEED · GAP · TIMER · WARM-UP · COOL-DOWN · BATTLE",
                Modifier.padding(horizontal=14.dp, vertical=16.dp))

            // Tab strip
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal=14.dp, vertical=8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TABS.forEach { t ->
                    Box(Modifier.border(2.dp, InkOnDark).background(if (t==tab) InkOnDark else BgDark)
                        .clickable { tab = t }.padding(horizontal=10.dp, vertical=8.dp)) {
                        Text(t, style=ChamberType.ButtonSm, color=if (t==tab) BgDark else InkOnDark)
                    }
                }
            }

            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp)) {
                item {
                    when (tab) {
                        "DRILL"  -> DrillTab(uiState, vm, nav)
                        "SPEED"  -> SpeedTab(uiState, vm)
                        "GAP"    -> GapTab(uiState, vm)
                        "TIMER"  -> TimerTab(uiState, vm)
                        "WARM-UP"-> WarmUpTab(uiState, vm)
                        "COOL-DOWN"-> CoolDownTab(uiState, vm)
                        "BATTLE" -> BattleTab(uiState, vm)
                    }
                }
                item { Spacer(Modifier.height(ChamberDimens.BottomPadding)) }
            }
        }
    }
}

// ── Speed climber tab ────────────────────────────────────────────────────────
@Composable
private fun SpeedTab(state: TrainerUiState, vm: TrainerViewModel) {
    val c = LocalChamberColors.current
    Column(Modifier.fillMaxWidth()) {
        HintBox("Start the click and climb the BPM until the pattern breaks. Mark the ceiling — that number is your new PR.",
            Modifier.background(BgDark))
        Spacer(Modifier.height(12.dp))
        // BPM + ramp settings
        NumRow("Ramp every (bars)", state.rampEveryBars, { vm.setRampBars(it) }, 1, 1, 16)
        NumRow("Ramp step (BPM)", state.rampStepBpm, { vm.setRampStep(it) }, 2, 1, 10)
        NumRow("Max BPM", state.rampMaxBpm, { vm.setRampMax(it) }, 5, 80, 300)
        Spacer(Modifier.height(12.dp))
        Text("CURRENT: ${state.bpm} BPM", style=ChamberType.Bpm, color=InkOnDark)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChamberButton(if (state.rampRunning) "■ STOP CLIMB" else "▶ START CLIMB",
                onClick = { if (state.rampRunning) vm.stopRamp() else vm.startRamp() },
                modifier = Modifier.weight(1f))
            ChamberButton(label = "RESET", onClick = { vm.resetBpm() }, modifier = Modifier.weight(0.4f))
        }
        Spacer(Modifier.height(8.dp))
        ChamberButton(label = "◎ MARK CEILING AT ${state.bpm} BPM", onClick = { vm.markCeiling() },
            modifier = Modifier.fillMaxWidth())
        if (state.recentPRs.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            SectionLine("TEMPO PRS", count=state.recentPRs.size)
            state.recentPRs.take(8).forEach { (name, pr) ->
                Row(Modifier.fillMaxWidth().border(2.dp, InkOnDark).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(name, style=ChamberType.BodyBold, color=InkOnDark, modifier=Modifier.weight(1f))
                    Text("$pr BPM", style=ChamberType.Mono, color=MutedOnDark)
                }
            }
        }
    }
}

// ── Gap trainer tab ──────────────────────────────────────────────────────────
@Composable
private fun GapTab(state: TrainerUiState, vm: TrainerViewModel) {
    Column(Modifier.fillMaxWidth()) {
        HintBox("The click disappears for N bars and returns. If you're still in time — your internal clock is real.",
            Modifier.background(BgDark))
        Spacer(Modifier.height(12.dp))
        NumRow("Bars WITH click", state.gapPlayBars, { vm.setGapPlay(it) }, 1, 1, 16)
        NumRow("Bars of SILENCE", state.gapMuteBars, { vm.setGapMute(it) }, 1, 1, 16)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("EASY" to Pair(4,1), "NORMAL" to Pair(2,2), "HARD" to Pair(1,3), "NIGHTMARE" to Pair(1,7)).forEach { (label, cfg) ->
                ChamberButton(label, onClick = { vm.setGapPreset(cfg.first, cfg.second) },
                    size=ButtonSize.Small, modifier=Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(8.dp))
        ChamberButton(if (state.gapRunning) "■ STOP GAP TRAINER" else "▶ START GAP TRAINER",
            onClick = { if (state.gapRunning) vm.stopGap() else vm.startGap() },
            modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text("THE DOTS GO HOLLOW WHEN THE CLICK DROPS OUT", style=ChamberType.MonoLabel, color=MutedOnDark)
    }
}

// ── Session timer tab ─────────────────────────────────────────────────────────
@Composable
private fun TimerTab(state: TrainerUiState, vm: TrainerViewModel) {
    // Update clock every 500ms while running
    var displayTime by remember { mutableStateOf("0:00") }
    LaunchedEffect(state.timerRunning, state.timerAccMs) {
        while (true) {
            val elapsed = if (state.timerRunning)
                state.timerAccMs + (System.currentTimeMillis() - state.timerStartMs)
            else state.timerAccMs
            val s = elapsed / 1000; displayTime = "${s/60}:${"%02d".format(s%60)}"
            delay(500)
        }
    }

    Column(Modifier.fillMaxWidth()) {
        HintBox("Start when you actually begin. This feeds your streak, weekly minutes, and the coach.",
            Modifier.background(BgDark))
        Spacer(Modifier.height(12.dp))
        ClockDisplay(displayTime, modifier=Modifier.fillMaxWidth())
        Text("SESSION TIME", style=ChamberType.MonoLabel, color=MutedOnDark,
            modifier=Modifier.fillMaxWidth().padding(top=4.dp, bottom=12.dp))

        var focus by remember { mutableStateOf(state.focus) }
        ChamberField(focus, { focus=it; vm.setFocus(it) }, label="Focus for this session",
            placeholder="e.g. tongue bass at 160, D&B transitions",
            modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        // Quick focus tags
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Tongue bass","Throat bass","Melody","SFX","D&B","Freestyle","Technique drill").forEach { t ->
                ChamberButton(t, onClick = { focus=t; vm.setFocus(t) }, size=ButtonSize.ExtraSmall)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChamberButton(if (state.timerRunning) "❚❚ PAUSE" else if (state.timerAccMs>0) "▶ RESUME" else "▶ START SESSION",
                onClick = { if (state.timerRunning) vm.pauseTimer() else vm.startTimer() },
                modifier=Modifier.weight(1f))
            ChamberButton(label = "■ FINISH & LOG", onClick = { vm.finishSession() }, modifier=Modifier.weight(1f))
        }
        if (state.timerAccMs > 0 || state.timerRunning) {
            Spacer(Modifier.height(8.dp))
            ChamberButton(label = "DISCARD", onClick = { vm.discardSession() },
                style=ButtonStyle.Danger, size=ButtonSize.Small, modifier=Modifier.fillMaxWidth())
        }
    }
}

// ── Warm-up tab ───────────────────────────────────────────────────────────────
private val WARMUP = listOf(
    Triple("Lip rolls","Loose lips, relaxed jaw — no sound yet", 60),
    Triple("Breath control","4 in / 4 hold / 4 out — fill the lungs fully", 60),
    Triple("Humming","Gentle nasal hum, feel the vibration in your chest", 60),
    Triple("Vowel slides","A-E-I-O-U slowly, exaggerate the mouth shape", 60),
    Triple("Soft tongue bass","Very gentle, no strain — just activating", 60),
    Triple("Lip oscillation","Slow and loose, 60 BPM, both inward and outward", 60),
    Triple("Click rolls","Half speed, clean and precise", 60),
    Triple("Full phrase","One easy 8-bar pattern at 80 BPM — voice is ready", 90)
)

@Composable
private fun WarmUpTab(state: TrainerUiState, vm: TrainerViewModel) {
    var wuIdx by remember { mutableStateOf(-1) }
    var wuLeft by remember { mutableStateOf(0) }
    var wuRunning by remember { mutableStateOf(false) }

    LaunchedEffect(wuRunning, wuIdx) {
        if (!wuRunning || wuIdx < 0) return@LaunchedEffect
        wuLeft = WARMUP[wuIdx].third
        while (wuLeft > 0 && wuRunning) {
            delay(1000); wuLeft--
            if (wuLeft <= 0) {
                if (wuIdx < WARMUP.size - 1) { wuIdx++; wuLeft = WARMUP[wuIdx].third }
                else { wuRunning = false; vm.recordWarmUp() }
            }
        }
    }

    Column(Modifier.fillMaxWidth()) {
        HintBox("Beatboxing is an athletic vocal sport. Warm up like one.",Modifier.background(BgDark))
        if (state.lastWarm.isNotBlank())
            Text("LAST WARM-UP: ${state.lastWarm}", style=ChamberType.Mono, color=MutedOnDark,
                modifier=Modifier.padding(top=8.dp))
        Spacer(Modifier.height(8.dp))
        if (wuRunning) {
            val s = wuLeft; ClockDisplay("${s/60}:${"%02d".format(s%60)}", small=true, modifier=Modifier.fillMaxWidth())
            Text("STEP ${wuIdx+1} OF ${WARMUP.size}", style=ChamberType.MonoLabel, color=MutedOnDark,
                modifier=Modifier.padding(top=4.dp, bottom=8.dp))
        }
        ChamberButton(if (wuRunning) "■ STOP" else "▶ START WARM-UP (${WARMUP.sumOf { it.third }/60} MIN)",
            onClick = { if (wuRunning) { wuRunning=false; wuIdx=-1 } else { wuRunning=true; wuIdx=0 } },
            modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        WARMUP.forEachIndexed { i, (name, desc, dur) ->
            val isActive = wuRunning && i == wuIdx
            Row(Modifier.fillMaxWidth().border(2.dp, InkOnDark)
                .background(if (isActive) InkOnDark else BgDark).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("${i+1}", style=ChamberType.SectionLine, color=if (isActive) BgDark else InkOnDark,
                    modifier=Modifier.width(34.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, style=ChamberType.BodyBold, color=if (isActive) BgDark else InkOnDark)
                    Text(desc, style=ChamberType.Mono, color=if (isActive) BgDark.copy(alpha=0.75f) else MutedOnDark)
                }
                Text(if (isActive && wuRunning) "${wuLeft/60}:${"%02d".format(wuLeft%60)}"
                    else "${dur/60}:${"%02d".format(dur%60)}",
                    style=ChamberType.MonoLabel, color=if (isActive) BgDark else MutedOnDark)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("If anything hurts, stop. Pain is not progress.",style=ChamberType.Mono,color=MutedOnDark)
    }
}

// ── Battle tab ────────────────────────────────────────────────────────────────
private val FORMATS = listOf(
    listOf("BUK SOLO",90,2,30), listOf("CLASSIC",60,2,30), listOf("WILDCARD",60,1,0),
    listOf("ELIMINATION",90,1,0), listOf("SHOWCASE",120,1,0), listOf("MARATHON",60,4,20)
)
@Composable
private fun BattleTab(state: TrainerUiState, vm: TrainerViewModel) {
    Column(Modifier.fillMaxWidth()) {
        HintBox("Simulate a battle: prep → rounds → rest. Use your setlist mentally. Metronome can run under it.")
        Spacer(Modifier.height(8.dp))
        ClockDisplay(
            time = when { state.battleState == "idle" -> "${state.battleLen/60}:${"%02d".format(state.battleLen%60)}"
                else -> "${state.battleLeft/60}:${"%02d".format(state.battleLeft%60)}" },
            alert = state.battleState == "round", modifier=Modifier.fillMaxWidth())
        Text(when(state.battleState){
            "prep" -> "GET READY"; "round" -> "ROUND ${state.battleRound} OF ${state.battleRounds}"
            "rest" -> "REST"; "done" -> "FINISHED"; else -> "READY"
        } + " · ${state.battleRounds} × ${state.battleLen}s",
            style=ChamberType.MonoLabel, color=MutedOnDark, modifier=Modifier.padding(top=4.dp,bottom=8.dp))

        ChamberButton(if (state.battleRunning) "■ ABORT" else "▶ START BATTLE",
            onClick = { if (state.battleRunning) vm.battleStop() else vm.battleStart() },
            modifier=Modifier.fillMaxWidth())
        if (state.battleState == "done") {
            Spacer(Modifier.height(8.dp))
            ChamberButton("LOG SESSION", onClick = { vm.logBattleSession() }, modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(12.dp))
        SectionLine("FORMAT")
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical=6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FORMATS.forEach { f ->
                val active = state.battleLen == f[1] && state.battleRounds == f[2]
                ChamberButton(f[0] as String, size=ButtonSize.Small,
                    onClick = { vm.setBattleFormat(f[1] as Int, f[2] as Int, f[3] as Int) },
                    modifier=if (active) Modifier.border(3.dp, InkOnDark) else Modifier)
            }
        }
        Spacer(Modifier.height(8.dp))
        NumRow("Round length (sec)", state.battleLen, { vm.setBattleLen(it) }, 15, 15, 600)
        NumRow("Rounds", state.battleRounds, { vm.setBattleRounds(it) }, 1, 1, 10)
        NumRow("Rest between (sec)", state.battleRest, { vm.setBattleRest(it) }, 5, 0, 180)
        NumRow("Count-in (sec)", state.battlePrep, { vm.setBattlePrep(it) }, 1, 0, 30)
        Spacer(Modifier.height(10.dp))
        Text("TIP: Run a full setlist in your head each round. No stopping to fix mistakes.",
            style = ChamberType.Mono, color = MutedOnDark)
    }
}

// ── Shared num-row widget ─────────────────────────────────────────────────────
@Composable
private fun NumRow(label: String, value: Int, onChange: (Int) -> Unit, step: Int, min: Int, max: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical=4.dp), verticalAlignment=Alignment.CenterVertically) {
        Text(label, style=ChamberType.Mono, color=MutedOnDark, modifier=Modifier.weight(1f))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.border(2.dp,InkOnDark).clickable { if (value>min) onChange(value-step) }.padding(horizontal=12.dp,vertical=6.dp))
            { Text("−", style=ChamberType.ButtonSm, color=InkOnDark) }
            Text("$value", style=ChamberType.MonoLabel, color=InkOnDark, modifier=Modifier.width(48.dp))
            Box(Modifier.border(2.dp,InkOnDark).clickable { if (value<max) onChange(value+step) }.padding(horizontal=12.dp,vertical=6.dp))
            { Text("+", style=ChamberType.ButtonSm, color=InkOnDark) }
        }
    }
}


// ── Drill tab (intelligent session builder) ───────────────────────────────────

@Composable
private fun DrillTab(state: TrainerUiState, vm: TrainerViewModel, nav: NavHostController) {
    val plan = state.drillPlan
    val c = LocalChamberColors.current

    // Minute selector
    Text("SESSION LENGTH", style = ChamberType.MonoLabel, color = c.muted)
    Spacer(Modifier.height(6.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf(15, 30, 45, 60).forEach { m ->
            val selected = state.drillTargetMin == m
            Box(
                Modifier
                    .border(2.dp, c.ink)
                    .background(if (selected) c.ink else c.bg)
                    .clickable { vm.setDrillMinutes(m) }
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text("${m}m", style = ChamberType.ButtonSm, color = if (selected) c.bg else c.ink)
            }
        }
    }

    Spacer(Modifier.height(14.dp))

    // Build / Rebuild
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ChamberButton(
            label = if (plan == null) "BUILD PLAN" else "REBUILD",
            onClick = { if (plan == null) vm.buildDrill() else vm.rebuildDrill() },
            modifier = Modifier.weight(1f)
        )
        if (plan != null && !state.drillRunning) {
            ChamberButton(
                label = "START",
                onClick = { vm.startDrill() },
                modifier = Modifier.weight(1f)
            )
        }
    }

    if (plan != null) {
        Spacer(Modifier.height(16.dp))
        Text(
            "PLAN · ${plan.totalMinutes} MIN · ${plan.blocks.size} BLOCKS",
            style = ChamberType.MonoLabel,
            color = c.muted
        )
        Spacer(Modifier.height(8.dp))

        plan.blocks.forEachIndexed { i, block ->
            val active = state.drillRunning && state.drillIndex == i
            Column(
                Modifier
                    .fillMaxWidth()
                    .border(2.dp, if (active) Color(0xFFCC0000) else c.ink)
                    .background(if (active) c.ink else c.bg)
                    .padding(12.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "${i + 1}. ${block.name}",
                        style = ChamberType.BodyBold,
                        color = if (active) c.bg else c.ink,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        "${block.minutes}m" + if (block.bpm > 0) " · ${block.bpm}" else "",
                        style = ChamberType.MonoLabel,
                        color = if (active) c.bg else c.muted
                    )
                }
                if (block.why.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        block.why,
                        style = ChamberType.Mono,
                        color = if (active) c.bg.copy(alpha = 0.75f) else c.muted
                    )
                }
            }
            Spacer(Modifier.height(2.dp))
        }

        // Running controls
        if (state.drillRunning) {
            Spacer(Modifier.height(16.dp))
            val mins = state.drillBlockLeftSec / 60
            val secs = state.drillBlockLeftSec % 60
            Text(
                "BLOCK TIME  %d:%02d".format(mins, secs),
                style = ChamberType.Brand,
                color = c.ink
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (state.drillPaused) {
                    ChamberButton(label = "RESUME", onClick = { vm.resumeDrill() }, modifier = Modifier.weight(1f))
                } else {
                    ChamberButton(label = "PAUSE", onClick = { vm.pauseDrill() }, modifier = Modifier.weight(1f))
                }
                ChamberButton(label = "NEXT", onClick = { vm.nextDrillBlock() }, modifier = Modifier.weight(1f))
                ChamberButton(label = "FINISH", onClick = { vm.finishDrill() }, modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.height(6.dp))
            ChamberButton(label = "ABANDON", onClick = { vm.abandonDrill() }, modifier = Modifier.fillMaxWidth())
        }
    } else {
        Spacer(Modifier.height(14.dp))
        HintBox(
            "DRILL builds a timed session from your own data: warm-up if cold, techniques due for review, unfinished champs, tempo gaps, cold genres, pattern lock, and a battle round. Press BUILD PLAN."
        )
    }
}


// ── Cool-down tab ─────────────────────────────────────────────────────────────
private val COOLDOWN = listOf(
    Triple("Straw phonation", "Hum through a straw into water or air — gentle, steady airflow", 90),
    Triple("Soft hum descent", "Slide from mid range down to the lowest comfortable note", 60),
    Triple("Silence + breath", "Jaw relaxed, nasal breathing only — no sound for a full minute", 60)
)

@Composable
private fun CoolDownTab(state: TrainerUiState, vm: TrainerViewModel) {
    var cdIdx by remember { mutableStateOf(-1) }
    var cdLeft by remember { mutableStateOf(0) }
    var cdRunning by remember { mutableStateOf(false) }

    LaunchedEffect(cdRunning, cdIdx) {
        if (!cdRunning || cdIdx < 0) return@LaunchedEffect
        while (cdLeft > 0 && cdRunning) {
            delay(1000)
            cdLeft--
        }
        if (cdRunning && cdLeft <= 0) {
            if (cdIdx < COOLDOWN.size - 1) {
                cdIdx++
                cdLeft = COOLDOWN[cdIdx].third
            } else {
                cdRunning = false
                cdIdx = -1
            }
        }
    }

    Column {
        HintBox("Cool-down protects the voice after hard sessions. Do this even if you feel fine.")
        Spacer(Modifier.height(10.dp))
        if (cdIdx >= 0) {
            Text("STEP ${cdIdx + 1} OF ${COOLDOWN.size}", style = ChamberType.MonoLabel, color = MutedOnDark)
            Spacer(Modifier.height(6.dp))
        }
        ChamberButton(
            if (cdRunning) "■ STOP"
            else "▶ START COOL-DOWN (${COOLDOWN.sumOf { it.third } / 60} MIN)",
            onClick = {
                if (cdRunning) {
                    cdRunning = false; cdIdx = -1; cdLeft = 0
                } else {
                    cdIdx = 0; cdLeft = COOLDOWN[0].third; cdRunning = true
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        COOLDOWN.forEachIndexed { i, (name, desc, dur) ->
            val isActive = cdIdx == i
            Row(
                Modifier.fillMaxWidth().border(2.dp, InkOnDark)
                    .background(if (isActive) InkOnDark else BgDark).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("${i + 1}", style = ChamberType.SectionLine, color = if (isActive) BgDark else InkOnDark,
                    modifier = Modifier.width(34.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, style = ChamberType.BodyBold, color = if (isActive) BgDark else InkOnDark)
                    Text(desc, style = ChamberType.Mono, color = if (isActive) BgDark.copy(alpha = 0.75f) else MutedOnDark)
                }
                Text(
                    if (isActive && cdRunning) "${cdLeft / 60}:${"%02d".format(cdLeft % 60)}"
                    else "${dur / 60}:${"%02d".format(dur % 60)}",
                    style = ChamberType.MonoLabel,
                    color = if (isActive) BgDark else MutedOnDark
                )
            }
            Spacer(Modifier.height(2.dp))
        }
    }
}

