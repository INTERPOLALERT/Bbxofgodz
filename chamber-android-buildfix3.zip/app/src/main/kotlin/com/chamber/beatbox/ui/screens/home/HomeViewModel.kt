package com.chamber.beatbox.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chamber.beatbox.data.db.dao.GameStateDao
import com.chamber.beatbox.data.db.entities.EntryEntity
import com.chamber.beatbox.data.db.entities.GameStateEntity
import com.chamber.beatbox.data.db.entities.PracticeLogEntity
import com.chamber.beatbox.data.drill.DrillBuilder
import com.chamber.beatbox.data.repository.EntryRepository
import com.chamber.beatbox.data.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import javax.inject.Inject
import kotlin.math.min

data class HomeQuestPreview(val id: String, val title: String, val done: Boolean)

data class HomeState(
    val level: Int = 1,
    val rank: String = "NOVICE",
    val xp: Int = 0,
    val streak: Int = 0,
    val totalMinutes: Int = 0,
    val fileCount: Int = 0,
    val dailyQuests: List<HomeQuestPreview> = emptyList(),
    val dailyQuestDone: Int = 0,
    val dailyQuestTotal: Int = 0,
    val reviewDue: List<EntryEntity> = emptyList(),
    val pinned: List<EntryEntity> = emptyList(),
    val recentEntries: List<EntryEntity> = emptyList(),
    val weekMinutes: List<Pair<String, Int>> = emptyList(),
    val eventName: String = "",
    val eventDate: String = "",
    val eventDaysLeft: Int? = null,
    val drillMinutes: Int = 30
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repo: EntryRepository,
    private val gameStateDao: GameStateDao,
    private val settings: SettingsRepository
) : ViewModel() {

    private data class Bundle(
        val entries: List<EntryEntity>,
        val gameState: GameStateEntity?,
        val sessions: List<PracticeLogEntity>,
        val eventDate: String,
        val eventName: String,
        val drillMin: Int,
        val fileCount: Int
    )

    private val a = combine(
        repo.observeAll(),
        gameStateDao.observe(),
        repo.observeRecentSessions(200)
    ) { e, g, s -> Triple(e, g, s) }

    private val b = combine(
        settings.eventDate,
        settings.eventName,
        settings.drillMin,
        repo.observeFileCount()
    ) { ed, en, dm, fc -> listOf(ed, en, dm, fc) }

    val state: StateFlow<HomeState> = combine(a, b) { trip, rest ->
        val entries = trip.first
        val gameState = trip.second
        val sessions = trip.third
        val eventDate = rest[0] as String
        val eventName = rest[1] as String
        val drillMin = rest[2] as Int
        val fileCount = rest[3] as Int
        build(entries, gameState, sessions, eventDate, eventName, drillMin, fileCount)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeState())

    private fun build(
        entries: List<EntryEntity>,
        gameState: GameStateEntity?,
        sessions: List<PracticeLogEntity>,
        eventDate: String,
        eventName: String,
        drillMin: Int,
        fileCount: Int
    ): HomeState {
        val live = entries.filter { !it.deleted }
        val xp = gameState?.xp ?: 0
        val level = levelOf(xp)
        val allDays = sessions.map { it.day }.toSet()
        val quests = parseDailyQuests(gameState?.questJson ?: "{}")
        val review = DrillBuilder.reviewQueue(live, limit = 3).map { it.technique }
        val pins = live.filter { it.pin }.sortedByDescending { it.updatedAt }.take(5)
        val recent = live
            .filter { it.kind != "genre" || it.links != "[]" || !it.notes.isNullOrBlank() }
            .sortedByDescending { it.updatedAt }
            .take(5)
        val today = LocalDate.now()
        val weekMins = (6 downTo 0).map { back ->
            val day = today.minusDays(back.toLong()).toString()
            day.takeLast(5) to sessions.filter { it.day == day }.sumOf { it.minutes }
        }
        val daysLeft: Int? = try {
            if (eventDate.isBlank()) null
            else ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(eventDate.take(10))).toInt()
        } catch (_: Exception) { null }

        return HomeState(
            level = level,
            rank = rankOf(level),
            xp = xp,
            streak = computeStreak(allDays),
            totalMinutes = sessions.sumOf { it.minutes },
            fileCount = fileCount,
            dailyQuests = quests,
            dailyQuestDone = quests.count { it.done },
            dailyQuestTotal = quests.size,
            reviewDue = review,
            pinned = pins,
            recentEntries = recent,
            weekMinutes = weekMins,
            eventName = eventName,
            eventDate = eventDate,
            eventDaysLeft = daysLeft,
            drillMinutes = drillMin
        )
    }

    companion object {
        private val RANKS = listOf(
            "NOVICE","ROOKIE","APPRENTICE","JOURNEYMAN","SKILLED","ADEPT",
            "PROFICIENT","EXPERT","MASTER","GRANDMASTER","CHAMPION","ELITE","LEGEND","MYTHIC","TRANSCENDENT"
        )
        fun levelOf(xp: Int): Int {
            var level = 1
            while (xpForLevel(level + 1) <= xp) level++
            return level
        }
        fun xpForLevel(l: Int) = 30 * (l - 1) * l
        fun rankOf(level: Int) = RANKS[min(RANKS.size - 1, level - 1)]

        private fun computeStreak(days: Set<String>): Int {
            var streak = 0
            var check = LocalDate.now()
            while (days.contains(check.toString())) {
                streak++
                check = check.minusDays(1)
            }
            return streak
        }

        private fun parseDailyQuests(questJson: String): List<HomeQuestPreview> {
            return runCatching {
                val obj = Json.parseToJsonElement(questJson).jsonObject
                val arr = obj["states"]?.jsonArray ?: return emptyList()
                arr.mapNotNull { el ->
                    val o = el.jsonObject
                    val id = o["id"]?.jsonPrimitive?.content ?: return@mapNotNull null
                    if (id.startsWith("b")) return@mapNotNull null
                    val done = o["done"]?.jsonPrimitive?.booleanOrNull ?: false
                    val title = o["title"]?.jsonPrimitive?.contentOrNull
                    HomeQuestPreview(id, title ?: id, done)
                }.take(3)
            }.getOrElse { emptyList() }
        }
    }
}
