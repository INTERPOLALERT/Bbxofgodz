package com.chamber.beatbox.ui.screens.visualizer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chamber.beatbox.data.audio.VisualizerEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class VisualizerViewModel @Inject constructor(
    private val engine: VisualizerEngine
) : ViewModel() {

    private val _mode = MutableStateFlow(VisualizerEngine.Mode.SPECTRUM)
    val mode: StateFlow<VisualizerEngine.Mode> = _mode.asStateFlow()

    val isRunning: StateFlow<Boolean> = engine.isRunning

    // Collect frames — use shareIn so the Canvas gets the latest without
    // re-subscribing on every recomposition
    val latestFrame: StateFlow<VisualizerEngine.VisualizerFrame?> = engine.frames
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun setMode(mode: VisualizerEngine.Mode) { _mode.value = mode; engine.mode = mode }

    fun start() = engine.start()
    fun stop()  = engine.stop()

    override fun onCleared() {
        super.onCleared()
        engine.stop()
    }
}
