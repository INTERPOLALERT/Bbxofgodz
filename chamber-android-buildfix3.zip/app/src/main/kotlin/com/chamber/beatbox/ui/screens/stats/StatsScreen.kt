package com.chamber.beatbox.ui.screens.stats

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.chamber.beatbox.ui.components.*
import com.chamber.beatbox.ui.theme.*

@Composable
fun StatsScreen(nav: NavHostController, vm: StatsViewModel = hiltViewModel()) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val c = LocalChamberColors.current

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(ChamberDimens.ContentPaddingH)) {
        item { Spacer(Modifier.height(ChamberDimens.ContentPaddingV)); SectionHead("∑","Stats","STREAKS · TIME · BALANCE · BADGES",Modifier.padding(bottom=14.dp)) }

        // Headline tiles
        item {
            Row(Modifier.fillMaxWidth()) {
                StatTile(state.streak.toString(), "DAY STREAK", modifier=Modifier.weight(1f))
                StatTile(state.totalMinutes.toString(), "MIN TOTAL", modifier=Modifier.weight(1f))
                StatTile(state.sessionCount.toString(), "SESSIONS", modifier=Modifier.weight(1f))
                StatTile(state.entryCount.toString(), "ENTRIES", modifier=Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
        }

        // 8-week bar chart
        item {
            SectionLine("8-Week Practice (min/day)")
            Spacer(Modifier.height(8.dp))
            if (state.weeklyBars.isNotEmpty()) {
                PracticeBarChart(state.weeklyBars, modifier=Modifier.fillMaxWidth().height(120.dp))
            } else {
                HintBox("No sessions logged yet. Start a session in Trainer to see your chart.")
            }
            Spacer(Modifier.height(12.dp))
        }

        // Avg minutes per day
        item {
            ChamberProgressBar("AVG DAILY (THIS WEEK)", state.avgDailyThisWeek, 120, " min")
            Spacer(Modifier.height(6.dp))
            ChamberProgressBar("AVG DAILY (ALL TIME)", state.avgDailyAllTime, 120, " min")
            Spacer(Modifier.height(12.dp))
        }

        // Technique library coverage
        item {
            SectionLine("Technique Coverage")
            Spacer(Modifier.height(8.dp))
            val cats = listOf("technique","musicality","tonguebass","sfx","singing")
            cats.forEach { cat ->
                val count = state.techniqueCounts[cat] ?: 0
                ChamberProgressBar(cat.uppercase(), count, 20, " entries")
                Spacer(Modifier.height(4.dp))
            }
            Spacer(Modifier.height(8.dp))
        }

        // Vocal strain tracker
        item {
            SectionLine("Vocal Strain (recent sessions)")
            Spacer(Modifier.height(8.dp))
            if (state.recentStrain.isEmpty()) {
                HintBox("Log strain after sessions to track vocal health.")
            } else {
                state.recentStrain.take(7).forEach { (day, strain) ->
                    Row(Modifier.fillMaxWidth().padding(vertical=2.dp), verticalAlignment=Alignment.CenterVertically) {
                        Text(day, style=ChamberType.Mono, color=c.muted, modifier=Modifier.width(90.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                            (1..5).forEach { n ->
                                Box(Modifier.size(20.dp).border(1.dp, if(n<=strain)Red else c.ink)
                                    .background(if(n<=strain)Red else c.bg))
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        // Recent focus areas
        item {
            SectionLine("Recent Focus Areas")
            Spacer(Modifier.height(8.dp))
            if (state.focusTags.isEmpty()) {
                HintBox("Focus tags appear here as you log sessions.")
            } else {
                state.focusTags.take(8).forEach { (tag, count) ->
                    Row(Modifier.fillMaxWidth().border(ChamberDimens.BorderWidth, c.ink).padding(10.dp),
                        verticalAlignment=Alignment.CenterVertically) {
                        Text(tag, style=ChamberType.BodyBold, color=c.ink, modifier=Modifier.weight(1f))
                        Text("$count× sessions", style=ChamberType.Mono, color=c.muted)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }


        // BPM coverage
        item {
            SectionLine("BPM Coverage")
            Spacer(Modifier.height(8.dp))
            if (state.bpmCoverage.isEmpty()) {
                HintBox("Entries with a BPM value will fill these bands.")
            } else {
                state.bpmCoverage.forEach { (label, covered) ->
                    Row(
                        Modifier.fillMaxWidth().border(ChamberDimens.BorderWidth, c.ink).padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(label, style = ChamberType.BodyBold, color = c.ink, modifier = Modifier.weight(1f))
                        Text(
                            if (covered) "COVERED" else "GAP",
                            style = ChamberType.MonoLabel,
                            color = if (covered) c.ink else Color(0xFFCC0000)
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        // Log vocal strain
        item {
            SectionLine("Log Vocal Strain (1–5)")
            Spacer(Modifier.height(8.dp))
            HintBox("After a hard session, rate throat strain. This feeds the health histogram above.")
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (1..5).forEach { n ->
                    Box(
                        Modifier
                            .size(44.dp)
                            .border(2.dp, c.ink)
                            .clickable { vm.logStrain(n) }
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("$n", style = ChamberType.BodyBold, color = c.ink)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        item { Spacer(Modifier.height(ChamberDimens.BottomPadding)) }
    }
}

@Composable
private fun PracticeBarChart(bars: List<Pair<String, Int>>, modifier: Modifier = Modifier) {
    val c = LocalChamberColors.current
    val maxVal = bars.maxOfOrNull { it.second }?.toFloat()?.coerceAtLeast(1f) ?: 1f
    Canvas(modifier.border(ChamberDimens.BorderWidth, c.ink)) {
        val w = size.width; val h = size.height
        val barW = w / bars.size
        val padH = 8.dp.toPx(); val padB = 20.dp.toPx()
        val chartH = h - padH - padB

        bars.forEachIndexed { i, (_, mins) ->
            val barH = (mins / maxVal) * chartH
            val x = i * barW
            // Bar
            if (barH > 0) drawRect(c.ink, Offset(x + 2f, h - padB - barH), Size(barW - 4f, barH))
            // Baseline
            drawLine(c.muted, Offset(x, h - padB), Offset(x + barW, h - padB), 1.dp.toPx())
        }
    }
}
