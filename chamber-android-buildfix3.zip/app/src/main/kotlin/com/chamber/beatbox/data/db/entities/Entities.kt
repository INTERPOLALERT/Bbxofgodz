package com.chamber.beatbox.data.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

// ============================================================
// ENTRY — the core polymorphic record type.
//
// Matches the HTML's IndexedDB 'entries' store exactly.
// Kind discriminates the type: champ, idea, bars, oneshot,
// technique, genre, social, vocode, goal, session, pattern, setlist.
//
// Universal fields are typed columns. Kind-specific fields
// live in `extraJson` (Map<String,String?> serialized as JSON).
// This keeps the schema stable and avoids a migration for every
// new field the HTML version adds.
//
// Rating history and tempo PRs share the `log` JSON column —
// each entry is: {d, t, k, v} where k is the field name.
// Links (cross-references to other entry IDs) are stored as
// a JSON string array in `links`.
// ============================================================
@Entity(tableName = "entries")
data class EntryEntity(
    @PrimaryKey
    val id: String,

    /** Discriminator: champ | idea | bars | oneshot | technique |
     *  genre | social | vocode | goal | session | pattern | setlist */
    val kind: String,

    val name: String,

    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis(),

    /** Soft-delete flag. Trashed entries survive in the DB until
     *  permanently purged so they can be restored. */
    val deleted: Boolean = false,

    /** Pinned to top of section list and shown on home screen. */
    val pin: Boolean = false,

    // ---- shared typed fields (null = not set for this kind) ----
    val bpm: Int? = null,
    val status: String? = null,
    val notes: String? = null,
    val description: String? = null,

    /** Technique category: technique | musicality | tonguebass | sfx | singing */
    val cat: String? = null,

    /** Bars count for bars kind: 4 | 8 | 16 */
    val bars: Int? = null,

    // ---- JSON columns (kind-specific and list fields) ----
    /** JSON array of linked entry IDs: ["id1","id2",...] */
    val links: String = "[]",

    /** JSON array of LogEntry objects: [{d,t,k,v},...].
     *  Used for: rating history (confidence, speed, cleanliness,
     *  musicality, difficulty, groove, performance, quality)
     *  and tempo PRs (k="bpm"). */
    val log: String = "[]",

    /** JSON array of tag strings: ["tag1","tag2",...].
     *  Also used for techniques[], genre[], relgenres[], etc.
     *  depending on kind. */
    val tags: String = "[]",

    /** JSON object for all remaining kind-specific fields.
     *  Examples: mood, inspiration, hook, caption, platform,
     *  bpmRange, artists, deadlines, items[], checklist[],
     *  review{}, pattern grid, swing, res, sig, etc.
     *
     *  Adding new fields never requires a DB migration. */
    @ColumnInfo(name = "extra_json")
    val extraJson: String = "{}"
)

// ============================================================
// FILE METADATA — matches HTML's 'fmeta' store.
// Actual audio/media files live on disk; we store the path.
// ============================================================
@Entity(
    tableName = "file_meta",
    indices = [Index(value = ["entry_id"])]
)
data class FileMetaEntity(
    @PrimaryKey
    val id: String,

    @ColumnInfo(name = "entry_id")
    val entryId: String,

    /** Filename as displayed in the UI. */
    val name: String,

    /** Absolute path to the file in app-private storage.
     *  Use FileProvider when sharing externally. */
    val path: String,

    /** MIME type: audio/m4a, audio/mp4, image/jpeg, etc. */
    val mime: String,

    val size: Long = 0L,

    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),

    /** Duration in milliseconds for audio/video files. 0 if unknown. */
    val duration: Long = 0L,

    /** User-editable caption/description. */
    val description: String = "",

    /** Whether this file has been soft-deleted with its entry. */
    val deleted: Boolean = false
)

// ============================================================
// PRACTICE LOG — matches HTML's PLOG array (persisted as KV).
// One row per completed session or battle.
// ============================================================
@Entity(tableName = "practice_log")
data class PracticeLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    /** "practice" | "battle" | "drill" */
    val type: String,

    /** ISO date string: "2025-01-15" */
    val day: String,

    /** Unix millis timestamp. */
    val timestamp: Long = System.currentTimeMillis(),

    val minutes: Int,

    /** User-entered focus label, e.g. "tongue bass at 160". */
    val focus: String = "",

    /** Session quality rating 1–5. Null if not logged. */
    val rating: Int? = null,

    /** Vocal strain rating 1–5. Null if not logged. */
    val strain: Int? = null,

    /** Free-text notes. */
    val note: String = "",

    /** Metronome BPM at session end. */
    val bpm: Int? = null,

    // Battle-specific
    val rounds: Int? = null,
    val roundLength: Int? = null
)

// ============================================================
// HEALTH LOG — tracks vocal strain per session.
// Separate from practice_log so queries stay cheap.
// ============================================================
@Entity(tableName = "health_log")
data class HealthLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val timestamp: Long = System.currentTimeMillis(),
    val day: String,
    val strain: Int,
    val minutes: Int
)

// ============================================================
// GAME STATE — XP, level, quests.
// Single-row table (id always = 1).
// ============================================================
@Entity(tableName = "game_state")
data class GameStateEntity(
    @PrimaryKey
    val id: Int = 1,

    val xp: Int = 0,

    /** JSON object: { daily: QuestState[], boss: QuestState|null,
     *                 weekKey: String } */
    @ColumnInfo(name = "quest_json")
    val questJson: String = "{}",

    /** JSON array of earned badge IDs. */
    @ColumnInfo(name = "badges_json")
    val badgesJson: String = "[]",

    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis()
)

// ============================================================
// SETTINGS — key/value store (matches HTML's KV IndexedDB store
// and the SET object). DataStore handles simple prefs; complex
// structured settings (like GODMODE graph positions) go here.
// ============================================================
@Entity(tableName = "kv_store")
data class KvEntity(
    @PrimaryKey
    val key: String,

    /** JSON-encoded value. Primitives, arrays, and objects all
     *  serialize the same way. */
    val value: String
)
