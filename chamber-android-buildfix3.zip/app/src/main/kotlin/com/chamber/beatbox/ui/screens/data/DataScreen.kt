package com.chamber.beatbox.ui.screens.data

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.chamber.beatbox.data.db.entities.EntryEntity
import com.chamber.beatbox.ui.components.*
import com.chamber.beatbox.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DataScreen(nav: NavHostController, vm: DataViewModel = hiltViewModel()) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val c = LocalChamberColors.current

    // File picker for import
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.importJson(it) }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(ChamberDimens.ContentPaddingH)) {
        item { Spacer(Modifier.height(ChamberDimens.ContentPaddingV)); SectionHead("▤","Data / Backup","EVERYTHING LIVES ON THIS DEVICE — BACK IT UP",Modifier.padding(bottom=14.dp)) }


        item {
            SectionLine("NEXT COMPETITION")
            Spacer(Modifier.height(8.dp))
            HintBox("Same as HTML setEventSheet — countdown on Home.")
            Spacer(Modifier.height(8.dp))
            var name by remember { mutableStateOf(state.eventName) }
            var date by remember { mutableStateOf(state.eventDate) }
            LaunchedEffect(state.eventName) { name = state.eventName }
            LaunchedEffect(state.eventDate) { date = state.eventDate }
            ChamberField(name, { name = it }, label = "Event name", placeholder = "e.g. UK Beatbox Championship", modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            ChamberField(date, { date = it }, label = "Date (YYYY-MM-DD)", placeholder = "2026-09-01", modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ChamberButton("SAVE", onClick = {
                    vm.setEventName(name.trim())
                    vm.setEventDate(date.trim())
                    ChamberToast.show("Countdown set")
                }, modifier = Modifier.weight(1f))
                if (state.eventDate.isNotBlank()) {
                    ChamberButton("CLEAR", onClick = { vm.clearEvent(); name = ""; date = "" },
                        size = ButtonSize.Small, style = ButtonStyle.Danger)
                }
            }
            Spacer(Modifier.height(14.dp))
        }


        // Status message
        if (state.lastMessage.isNotBlank()) {
            item {
                Row(Modifier.fillMaxWidth().border(ChamberDimens.BorderWidth, c.ink)
                    .background(c.ink).padding(12.dp).clickable { vm.clearMessage() },
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(state.lastMessage, style=ChamberType.BodyBold, color=c.bg, modifier=Modifier.weight(1f))
                    Text("✕", style=ChamberType.MonoLabel, color=c.bg)
                }
                Spacer(Modifier.height(8.dp))
            }
        }

        // Storage overview
        item {
            Row(Modifier.fillMaxWidth()) {
                StatTile(state.entryCount.toString(), "ENTRIES", modifier=Modifier.weight(1f))
                StatTile(fmtSize(state.totalStorageBytes), "STORAGE", modifier=Modifier.weight(1f))
                StatTile(state.trashCount.toString(), "IN TRASH", modifier=Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
        }

        // Export
        item {
            SectionLine("Export")
            Spacer(Modifier.height(8.dp))
            HintBox("Exports all entries, practice logs, and settings as JSON. Recordings are listed by filename — back them up separately from the CHAMBER/recordings/ folder.")
            Spacer(Modifier.height(8.dp))
            ChamberButton(
                if (state.isExporting) "EXPORTING…" else "▤ EXPORT FULL BACKUP (JSON)",
                onClick = { if (!state.isExporting) vm.exportJson() },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
        }

        // Import
        item {
            SectionLine("Import")
            Spacer(Modifier.height(8.dp))
            HintBox("Imports a CHAMBER JSON backup. Existing entries with the same ID are updated; new entries are added. This does NOT delete existing data.")
            Spacer(Modifier.height(8.dp))
            ChamberButton(
                if (state.isImporting) "IMPORTING…" else "▤ IMPORT FROM BACKUP",
                onClick = { if (!state.isImporting) importLauncher.launch(arrayOf("application/json")) },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
        }

        // Trash
        item { SectionLine("Trash", count = state.trashCount) }
        if (state.trashedEntries.isEmpty()) {
            item { HintBox("Trash is empty."); Spacer(Modifier.height(8.dp)) }
        } else {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChamberButton("EMPTY TRASH", onClick = { vm.purgeAllTrashed() },
                        style = ButtonStyle.Danger, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(6.dp))
            }
            items(state.trashedEntries, key = { it.id }) { entry ->
                TrashRow(entry, onRestore = { vm.restoreEntry(entry.id) }, onPurge = { vm.purgeEntry(entry.id) })
            }
        }

        item { Spacer(Modifier.height(ChamberDimens.BottomPadding)) }
    }
}

@Composable
private fun TrashRow(entry: EntryEntity, onRestore: () -> Unit, onPurge: () -> Unit) {
    val c = LocalChamberColors.current
    Row(Modifier.fillMaxWidth().border(ChamberDimens.BorderWidth, c.ink).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(entry.name, style=ChamberType.BodyBold, color=c.ink)
            Text("${entry.kind.uppercase()} · DELETED ${fmtAgo(entry.updatedAt)}",
                style=ChamberType.Mono, color=c.muted)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ChamberButton("RESTORE", onClick=onRestore, size=ButtonSize.Small)
            ChamberButton("DELETE", onClick=onPurge, size=ButtonSize.Small, style=ButtonStyle.Danger)
        }
    }
    Spacer(Modifier.height(2.dp))
}

private fun fmtSize(b: Long): String = when {
    b > 1_073_741_824 -> "%.1f GB".format(b/1_073_741_824f)
    b > 1_048_576 -> "%.1f MB".format(b/1_048_576f)
    else -> "${(b/1024).coerceAtLeast(1)} KB"
}
private fun fmtAgo(t: Long): String {
    val s = (System.currentTimeMillis()-t)/1000
    return when { s<3600->"${s/60}M AGO"; s<86400->"${s/3600}H AGO"; else->"${s/86400}D AGO" }
}
