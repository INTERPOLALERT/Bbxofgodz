package com.chamber.beatbox.ui.screens.search

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.chamber.beatbox.data.db.entities.EntryEntity
import com.chamber.beatbox.ui.components.*
import com.chamber.beatbox.ui.navigation.Routes
import com.chamber.beatbox.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun SearchScreen(nav: NavHostController, vm: SearchViewModel = hiltViewModel()) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val c     = LocalChamberColors.current
    val focus = remember { FocusRequester() }

    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    Column(Modifier.fillMaxSize().background(c.bg)) {
        Row(
            Modifier.fillMaxWidth()
                .border(width = ChamberDimens.BorderThick, color = c.ink)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("⌕ ", style = ChamberType.Title, color = c.muted)
            BasicTextField(
                value         = state.query,
                onValueChange = { vm.setQuery(it) },
                textStyle     = ChamberType.Title.copy(color = c.ink),
                cursorBrush   = SolidColor(c.ink),
                singleLine    = true,
                modifier      = Modifier.weight(1f).focusRequester(focus),
                decorationBox = { inner ->
                    if (state.query.isEmpty()) {
                        Text("Search or command…", style = ChamberType.Title, color = c.muted)
                    }
                    inner()
                }
            )
            if (state.query.isNotEmpty()) {
                Text("✕", style = ChamberType.Title, color = c.muted,
                    modifier = Modifier.clickable { vm.clear() }.padding(start = 8.dp))
            }
        }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp)) {
            if (state.commands.isNotEmpty()) {
                item {
                    Text("ACTIONS", style = ChamberType.MonoLabel, color = c.muted)
                    Spacer(Modifier.height(6.dp))
                }
                items(state.commands, key = { it.label }) { cmd ->
                    Row(
                        Modifier.fillMaxWidth()
                            .border(2.dp, c.ink)
                            .clickable {
                                vm.execute(
                                    cmd,
                                    onNavigate = { nav.navigate(it) },
                                    onNewEntry = { id -> nav.navigate(Routes.entry(id)) }
                                )
                            }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(cmd.glyph, style = ChamberType.Brand, color = c.ink, modifier = Modifier.width(40.dp))
                        Text(cmd.label, style = ChamberType.BodyBold, color = c.ink, modifier = Modifier.weight(1f))
                        Text(cmd.meta, style = ChamberType.MonoLabel, color = c.muted)
                    }
                    Spacer(Modifier.height(2.dp))
                }
                item { Spacer(Modifier.height(12.dp)) }
            }

            if (state.query.isBlank()) {
                item {
                    HintBox("Type a name, tag, or command: 140 · bpm 160 · drill · battle · new idea · /pattern · metro")
                }
            } else if (state.results.isEmpty() && state.commands.isEmpty()) {
                item {
                    Text("No results for \"${state.query}\"", style = ChamberType.MonoLabel, color = c.muted)
                }
            }

            if (state.results.isNotEmpty()) {
                item {
                    Text("${state.results.size} RESULT${if (state.results.size == 1) "" else "S"}",
                        style = ChamberType.MonoLabel, color = c.muted)
                    Spacer(Modifier.height(6.dp))
                }
                items(state.results, key = { it.id }) { entry ->
                    SearchResultRow(entry, state.query) { nav.navigate(Routes.entry(entry.id)) }
                }
            }

            item { Spacer(Modifier.height(ChamberDimens.BottomPadding)) }
        }
    }
}

@Composable
private fun SearchResultRow(entry: EntryEntity, query: String, onClick: () -> Unit) {
    val c = LocalChamberColors.current
    Row(
        Modifier.fillMaxWidth().border(2.dp, c.ink).clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(glyphFor(entry.kind), style = ChamberType.Brand, color = c.ink, modifier = Modifier.width(40.dp))
        Column(Modifier.weight(1f)) {
            Text(entry.name.ifBlank { "Untitled" }, style = ChamberType.BodyBold, color = c.ink)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(entry.kind.uppercase(), style = ChamberType.MonoLabel, color = c.muted)
                entry.bpm?.let { Text("$it BPM", style = ChamberType.MonoLabel, color = c.muted) }
            }
        }
        Text(fmtDate(entry.updatedAt), style = ChamberType.MonoTiny, color = c.muted)
    }
    Spacer(Modifier.height(2.dp))
}

private fun glyphFor(kind: String) = when (kind) {
    "champ" -> "+"; "idea" -> "!"; "bars" -> "▤"; "oneshot" -> "1"; "genre" -> "♫"
    "social" -> "@"; "vocode" -> "≈"; "goal" -> "◎"; "session" -> "▸"
    "pattern" -> "▦"; "setlist" -> "≡"; "technique" -> "TEC"; else -> "·"
}

private fun fmtDate(t: Long) = SimpleDateFormat("d MMM", Locale.ENGLISH).format(Date(t))
