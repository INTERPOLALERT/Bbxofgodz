package com.chamber.beatbox.data.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Process
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.*

/**
 * Sample-accurate metronome engine using AudioTrack in streaming mode.
 *
 * Architecture mirrors the HTML's Web Audio lookahead scheduler:
 *   - A high-priority coroutine runs on [Dispatchers.IO] and pre-writes
 *     PCM frames to an AudioTrack buffer 200 ms ahead of playback.
 *   - Every beat's sample offset is computed exactly from BPM, so timing
 *     is deterministic regardless of coroutine scheduling jitter.
 *   - A [MutableSharedFlow] fires beat events with enough lead time for
 *     the UI to animate before the sound actually plays.
 *
 * Features:
 *   - BPM: 30–300
 *   - Beats (time sig numerator): 2–7
 *   - Accent on beat 1
 *   - Subdivisions: NONE, EIGHTH, SIXTEENTH, TRIPLET
 *   - Swing: 0.0 (straight) → 1.0 (full dotted)
 *   - Count-in: 0–4 silent bars before click activates
 *   - Gap mode: M bars click, N bars silent (internal clock training)
 *   - Ramp mode: auto-increase BPM every [rampBars] bars
 */
class MetronomeEngine {

    // ── Public state (read from UI thread; write via mutate fns) ─────────────
    @Volatile var bpm: Int = 100
        private set

    @Volatile var beats: Int = 4
        private set

    @Volatile var accent: Boolean = true

    @Volatile var audible: Boolean = true

    @Volatile var swing: Float = 0f          // 0.0–1.0 where 0.5 = straight

    @Volatile var subdivision: Subdivision = Subdivision.NONE

    @Volatile var countIn: Int = 0           // bars of silence before click

    // Gap mode
    var gapPlayBars: Int = 4
    var gapMuteBars: Int = 1
    var gapEnabled: Boolean = false

    // Ramp mode
    var rampEnabled: Boolean  = false
    var rampMaxBpm: Int       = 200
    var rampStepBpm: Int      = 2            // BPM per increment
    var rampEveryBars: Int    = 4            // bars per step

    // ── Beat events for UI sync ───────────────────────────────────────────────
    /** Emits before each beat fires. beatIndex = 0..beats-1, isMuted = gap mode. */
    data class BeatEvent(val beatIndex: Int, val isMuted: Boolean, val isAccent: Boolean)

    private val _beatFlow = MutableSharedFlow<BeatEvent>(extraBufferCapacity = 16)
    val beatFlow: SharedFlow<BeatEvent> = _beatFlow.asSharedFlow()

    // ── Running state ─────────────────────────────────────────────────────────
    private val _running = AtomicBoolean(false)
    private val _isRunningFlow = MutableStateFlow(false)
    val isRunningFlow: StateFlow<Boolean> = _isRunningFlow.asStateFlow()
    val isRunning: Boolean get() = _running.get()

    private var engineJob: Job? = null
    private var audioTrack: AudioTrack? = null
    private val engineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // ── Tap tempo ─────────────────────────────────────────────────────────────
    private val tapTimes = mutableListOf<Long>()

    // ── Audio constants ───────────────────────────────────────────────────────
    private val sampleRate = 44100
    private val channelConfig = AudioFormat.CHANNEL_OUT_MONO
    private val encoding = AudioFormat.ENCODING_PCM_16BIT

    /** Lookahead window in seconds. Write this many seconds of audio ahead. */
    private val lookaheadSec = 0.20

    /** UI is notified this many ms before the beat sample actually plays. */
    private val uiLeadMs = 50L

    // Click durations in samples
    private val accentClickLen  = sampleRate / 18   // ~55 ms
    private val normalClickLen  = sampleRate / 20   // 50 ms
    private val subClickLen     = sampleRate / 28   // ~36 ms

    // Pre-generated click buffers (reused every beat, no GC pressure)
    private var accentClickBuf: ShortArray = generateClick(1600.0, accentClickLen, 0.50)
    private var normalClickBuf: ShortArray = generateClick(1000.0, normalClickLen, 0.32)
    private var subClickBuf:    ShortArray = generateClick(800.0,  subClickLen,    0.18)
    private val silenceChunk  = ShortArray(sampleRate / 20)   // 50 ms reusable silence

    // ── Public API ────────────────────────────────────────────────────────────

    fun setBpm(value: Int) {
        bpm = value.coerceIn(30, 300)
    }

    fun setBeats(value: Int) {
        beats = value.coerceIn(2, 7)
    }

    fun start() {
        if (_running.getAndSet(true)) return
        _isRunningFlow.value = true
        setupAudioTrack()
        engineJob = engineScope.launch {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            runEngine()
        }
    }

    fun stop() {
        if (!_running.getAndSet(false)) return
        _isRunningFlow.value = false
        engineJob?.cancel()
        engineJob = null
        audioTrack?.apply {
            pause()
            flush()
            release()
        }
        audioTrack = null
    }

    fun toggle() { if (isRunning) stop() else start() }

    fun tap() {
        val now = System.currentTimeMillis()
        tapTimes.removeAll { now - it > 2500 }
        tapTimes.add(now)
        if (tapTimes.size >= 2) {
            val intervals = (1 until tapTimes.size).map { i ->
                (tapTimes[i] - tapTimes[i - 1]).toDouble()
            }
            val avg = intervals.average()
            setBpm((60_000.0 / avg).roundToInt())
        }
    }

    fun release() {
        stop()
        engineScope.cancel()
    }

    // ── Audio setup ───────────────────────────────────────────────────────────

    private fun setupAudioTrack() {
        val minBuf = AudioTrack.getMinBufferSize(sampleRate, channelConfig, encoding)
        // Buffer large enough for lookahead, at least 4× minimum
        val bufBytes = maxOf(minBuf * 4, (sampleRate * lookaheadSec * 2).toInt())
        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(encoding)
                    .setSampleRate(sampleRate)
                    .setChannelMask(channelConfig)
                    .build()
            )
            .setBufferSizeInBytes(bufBytes)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        audioTrack?.play()
    }

    // ── Engine loop ───────────────────────────────────────────────────────────

    private suspend fun runEngine() {
        val track = audioTrack ?: return

        // State managed entirely within this coroutine — no shared mutable state needed.
        var globalBeat        = 0L       // total beats since start (for gap/ramp)
        var countInBeats      = 0L       // beats before real click starts
        var barIndex          = 0        // current bar within gap pattern
        var gapBarCount       = 0        // bars played or muted in current phase
        var inGapMute         = false    // currently in silent phase
        var rampBarTracker    = 0        // bars since last ramp step

        // The lookahead position in samples relative to track start.
        // We maintain: writtenSamples ≥ (currentSamplePos + lookaheadSamples)
        var writtenSamples    = 0L
        val lookaheadSamples  = (sampleRate * lookaheadSec).toLong()

        // Time at track start, used for UI lead-time scheduling.
        val trackStartMs = System.currentTimeMillis()

        fun samplesPerBeat(): Long {
            return (sampleRate.toLong() * 60L) / bpm.toLong()
        }

        fun swingDelay(beatInBar: Int): Long {
            if (swing == 0f || subdivision == Subdivision.NONE) return 0L
            // Swing delays even-numbered sub-divisions (8th notes)
            // HTML uses swing ∈ [0,1] where 0.5 is straight
            // We interpret it as: even 8th notes pushed forward by swing * half-beat
            val halfBeat = samplesPerBeat() / 2
            return if (beatInBar % 2 == 1) (swing * halfBeat).toLong() else 0L
        }

        // Compute schedule for the next beat
        var nextBeatSample = 0L

        fun emitBeatEvent(beatInBar: Int, muted: Boolean) {
            // Fire UI event with lead-time before the sample plays
            val sampleTimeMs = trackStartMs + (nextBeatSample * 1000L / sampleRate)
            val leadMs = uiLeadMs
            val delayMs = (sampleTimeMs - System.currentTimeMillis() - leadMs)
                .coerceAtLeast(0L)
            engineScope.launch {
                delay(delayMs)
                _beatFlow.tryEmit(BeatEvent(beatInBar, muted, beatInBar == 0 && accent))
            }
        }

        while (isRunning && currentCoroutineContext().isActive) {
            val track2 = audioTrack ?: break
            val spb = samplesPerBeat()

            // Fill the buffer up to the lookahead window
            val headPos = track2.playbackHeadPosition.toLong()
            val target = headPos + lookaheadSamples

            while (writtenSamples < target && isRunning) {
                if (writtenSamples >= nextBeatSample) {
                    // ── Beat event ────────────────────────────────────────────
                    val beatInBar = (globalBeat % beats).toInt()
                    globalBeat++

                    // Count-in: silent bars at start
                    val inCountIn = globalBeat <= countIn * beats
                    if (inCountIn) {
                        countInBeats++
                    }

                    // Gap mode logic
                    var beatMuted = inCountIn
                    if (!inCountIn && gapEnabled) {
                        when {
                            !inGapMute -> {
                                // playing phase
                                if (beatInBar == 0) gapBarCount++
                                if (gapBarCount > gapPlayBars) {
                                    inGapMute = true
                                    gapBarCount = 1
                                }
                                beatMuted = false
                            }
                            inGapMute -> {
                                // silent phase
                                if (beatInBar == 0) gapBarCount++
                                if (gapBarCount > gapMuteBars) {
                                    inGapMute = false
                                    gapBarCount = 1
                                }
                                beatMuted = true
                            }
                        }
                    }

                    // Ramp mode: increment BPM every N bars
                    if (!inCountIn && rampEnabled && beatInBar == 0) {
                        rampBarTracker++
                        if (rampBarTracker >= rampEveryBars) {
                            rampBarTracker = 0
                            if (bpm < rampMaxBpm) {
                                setBpm(bpm + rampStepBpm)
                                // Regenerate click buffers if pitch should change with BPM
                            }
                        }
                    }

                    // Emit UI beat event
                    emitBeatEvent(beatInBar, beatMuted)

                    // Write click PCM at this beat's sample offset
                    val gapInBuf = writtenSamples - nextBeatSample
                    if (gapInBuf > 0) {
                        // We're slightly behind the scheduled beat — write silence to align
                        writeSilence(track2, gapInBuf.toInt().coerceAtMost(silenceChunk.size))
                        writtenSamples += gapInBuf.coerceAtMost(silenceChunk.size.toLong())
                    }

                    if (!beatMuted && audible) {
                        val clickBuf = when {
                            beatInBar == 0 && accent -> accentClickBuf
                            else                     -> normalClickBuf
                        }
                        writeShorts(track2, clickBuf)
                        writtenSamples += clickBuf.size

                        // Write subdivisions within this beat if enabled
                        if (subdivision != Subdivision.NONE) {
                            writeSubdivisions(track2, spb, clickBuf.size.toLong(), beatMuted)
                            writtenSamples += subdivisionSamples(spb)
                        }
                    }

                    // Schedule next beat with swing applied
                    nextBeatSample += spb + swingDelay(beatInBar)
                } else {
                    // Write silence up to the next beat
                    val remaining = (nextBeatSample - writtenSamples)
                        .coerceAtMost(silenceChunk.size.toLong()).toInt()
                    writeSilence(track2, remaining)
                    writtenSamples += remaining
                }
            }

            // Yield to allow coroutine cancellation and avoid busy-spinning
            delay(10)
        }
    }

    private fun writeSubdivisions(track: AudioTrack, spb: Long, afterSamples: Long, muted: Boolean) {
        if (muted || !audible) {
            writeSilence(track, subdivisionSamples(spb).toInt())
            return
        }
        val positions = subdivisionOffsets(spb)
        var cursor = afterSamples
        for (pos in positions) {
            val silence = (pos - cursor).toInt().coerceAtLeast(0)
            if (silence > 0) writeSilence(track, silence)
            writeShorts(track, subClickBuf)
            cursor = pos + subClickBuf.size
        }
        // Fill to end of beat
        val endPos = spb
        val tail = (endPos - cursor).toInt().coerceAtLeast(0)
        if (tail > 0) writeSilence(track, tail)
    }

    private fun subdivisionOffsets(spb: Long): List<Long> = when (subdivision) {
        Subdivision.NONE      -> emptyList()
        Subdivision.EIGHTH    -> listOf(spb / 2)
        Subdivision.SIXTEENTH -> listOf(spb / 4, spb / 2, 3 * spb / 4)
        Subdivision.TRIPLET   -> listOf(spb / 3, 2 * spb / 3)
    }

    private fun subdivisionSamples(spb: Long): Long = spb - normalClickLen

    private fun writeShorts(track: AudioTrack, buf: ShortArray) {
        track.write(buf, 0, buf.size)
    }

    private fun writeSilence(track: AudioTrack, samples: Int) {
        if (samples <= 0) return
        var remaining = samples
        while (remaining > 0) {
            val chunk = minOf(remaining, silenceChunk.size)
            track.write(silenceChunk, 0, chunk)
            remaining -= chunk
        }
    }

    // ── Click synthesis ───────────────────────────────────────────────────────

    /**
     * Generates a decaying sine tone at [freqHz] with peak amplitude [amplitude].
     * The decay is exponential (40 Neper/s) — matches the HTML's oscillator envelope.
     */
    private fun generateClick(freqHz: Double, lenSamples: Int, amplitude: Double): ShortArray {
        val buf = ShortArray(lenSamples)
        val decayRate = 40.0
        for (i in 0 until lenSamples) {
            val t = i.toDouble() / sampleRate
            val env = exp(-t * decayRate)
            val sample = (env * amplitude * sin(2.0 * PI * freqHz * t) * Short.MAX_VALUE)
                .roundToInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
            buf[i] = sample.toShort()
        }
        return buf
    }

    enum class Subdivision { NONE, EIGHTH, SIXTEENTH, TRIPLET }
}
