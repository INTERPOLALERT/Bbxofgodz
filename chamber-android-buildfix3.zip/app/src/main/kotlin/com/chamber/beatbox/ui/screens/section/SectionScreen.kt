package com.chamber.beatbox.ui.screens.section

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.chamber.beatbox.data.db.entities.EntryEntity
import com.chamber.beatbox.ui.components.*
import com.chamber.beatbox.ui.navigation.Routes
import com.chamber.beatbox.ui.theme.ChamberDimens
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun SectionScreen(
    sectionId: String,
    nav: NavHostController,
    vm: SectionViewModel = hiltViewModel<SectionViewModel, SectionViewModel.Factory> { factory ->
        factory.create(sectionId)
    }
) {
    val entries by vm.entries.collectAsStateWithLifecycle()
    val sec = Routes.sectionById[sectionId] ?: return

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            horizontal = ChamberDimens.ContentPaddingH,
            vertical   = ChamberDimens.ContentPaddingV
        )
    ) {
        // Header
        item {
            SectionHead(
                glyph    = sec.glyph,
                title    = sec.title,
                subtitle = sec.desc + " · " + entries.size + " ENTRIES",
                modifier = Modifier.padding(bottom = 14.dp)
            )
        }

        // New entry button
        item {
            val label = when {
                sec.bars != null -> "+ NEW ${sec.bars}-BAR EXERCISE"
                else             -> "+ NEW ${sec.title.uppercase().removeSuffix("S")}"
            }
            ChamberButton(
                label    = label,
                onClick  = { vm.createEntry(nav) },
                size     = com.chamber.beatbox.ui.components.ButtonSize.Big,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            )
        }

        if (entries.isEmpty()) {
            item {
                HintBox(
                    text = "Empty library. Tap the big button above — same flow as the HTML section list."
                )
            }
        }

        // Pinned entries float to top (same as HTML's sort)
        val pinned = entries.filter { it.pin }
        val unpinned = entries.filter { !it.pin }

        if (pinned.isNotEmpty()) {
            item { SectionLine("Pinned", count = pinned.size) }
            items(pinned, key = { it.id }) { entry ->
                EntryRow(entry, nav, Modifier.padding(bottom = -2.dp))
            }
        }

        if (unpinned.isNotEmpty()) {
            if (pinned.isNotEmpty()) {
                item { SectionLine("All", count = unpinned.size) }
            }
            items(unpinned, key = { it.id }) { entry ->
                EntryRow(entry, nav, Modifier.padding(bottom = 0.dp))
            }
        }

        // Bottom spacer for FAB
        item { Spacer(Modifier.height(ChamberDimens.BottomPadding)) }
    }
}

@Composable
private fun EntryRow(
    entry: EntryEntity,
    nav: NavHostController,
    modifier: Modifier = Modifier
) {
    val meta = buildMetaString(entry)
    ChamberRow(
        name     = entry.name,
        meta     = meta,
        glyph    = if (entry.pin) "📌" else null,
        onClick  = { nav.navigate(Routes.entry(entry.id)) },
        modifier = modifier.fillMaxWidth()
    )
}

private fun buildMetaString(entry: EntryEntity): String {
    val parts = mutableListOf<String>()
    entry.status?.let { parts.add(it.uppercase()) }
    entry.bpm?.let { parts.add("${it} BPM") }
    entry.cat?.let { parts.add(it.uppercase()) }
    entry.bars?.let { parts.add("${it} BARS") }
    val ago = fmtAgo(entry.updatedAt)
    parts.add(ago)
    return parts.joinToString(" · ")
}

private fun fmtAgo(t: Long): String {
    val s = (System.currentTimeMillis() - t) / 1000
    return when {
        s < 60      -> "NOW"
        s < 3600    -> "${s / 60}M AGO"
        s < 86400   -> "${s / 3600}H AGO"
        else        -> "${s / 86400}D AGO"
    }
}
